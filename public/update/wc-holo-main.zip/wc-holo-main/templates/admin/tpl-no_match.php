<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
?>
<div class="match">
    <table id="woholoTabel" class="table table-striped table-bordered form-table" style="width:100%">
        <thead>
        <tr>
            <th><?php _e('Product id','wooholo');?></th>
            <th><?php _e('Product title','wooholo');?></th>
            <th><?php _e('Product stock','wooholo');?></th>
            <th><?php _e('Product price','wooholo');?></th>
            <th><?php _e('holo sku','wooholo');?></th>
            <th><?php _e('Message','wooholo');?></th>
            <th><?php _e('Action','wooholo');?></th>
        </tr>
        </thead>
    </table>
    <div id="ploading"><?php _e('loading....','wooholo');?></div>
</div>

