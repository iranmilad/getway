<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
?>
<form method="post">
    <table class="form-table">
        <tbody>
        <tr>
            <th scope="row">
                <label for="invoice_items_no_holo_code ">
                    <?php _e('Invoice items without holo code','wooholo')?>
                </label>
            </th>
            <td>
                <select class="" name="invoice_items_no_holo_code">
                    <option value="0" <?php if(isset($_POST['invoice_items_no_holo_code'])&&$_POST['invoice_items_no_holo_code']=='0') echo 'selected'; else if(!isset($_POST['invoice_items_no_holo_code'])&&isset($options['invoice_items_no_holo_code'])&&$options['invoice_items_no_holo_code']=='0') echo 'selected'?>><?php _e('Failure to register','wooholo') ?></option>
                    <option value="1" <?php if(isset($_POST['invoice_items_no_holo_code'])&&$_POST['invoice_items_no_holo_code']=='1') echo 'selected'; else if(!isset($_POST['invoice_items_no_holo_code'])&&isset($options['invoice_items_no_holo_code'])&&$options['order_invoice_status']=='1') echo 'selected'?>><?php _e('Register only items with a code','wooholo') ?></option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="status_place_payment">
                    <?php _e('Status received place payment','wooholo')?>
                </label>
            </th>
            <td>
                <select class="" name="status_place_payment">
                    <option value="Installment" <?php if(isset($_POST['status_place_payment'])&&$_POST['status_place_payment']=='Installment') echo 'selected'; else if(!isset($_POST['status_place_payment'])&&isset($options['status_place_payment'])&&$options['status_place_payment']=='Installment') echo 'selected'?>><?php _e('Installment payment','wooholo') ?></option>
                    <option value="cash" <?php if(isset($_POST['status_place_payment'])&&$_POST['status_place_payment']=='cash') echo 'selected'; else if(!isset($_POST['status_place_payment'])&&isset($options['status_place_payment'])&&$options['status_place_payment']=='cash') echo 'selected'?>><?php _e('Cash payment','wooholo') ?></option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="sales_price_field">
                    <?php _e('Sales price field','wooholo')?>
                </label>
            </th>
            <td>
                <select class="" name="sales_price_field">
                    <option value="1" <?php if(isset($_POST['sales_price_field'])&&$_POST['sales_price_field']=='1') echo 'selected'; else if(!isset($_POST['sales_price_field'])&&isset($options['sales_price_field'])&&$options['sales_price_field']=='1') echo 'selected'?>><?php _e('price 1','wooholo') ?></option>
                    <option value="2" <?php if(isset($_POST['sales_price_field'])&&$_POST['sales_price_field']=='2') echo 'selected'; else if(!isset($_POST['sales_price_field'])&&isset($options['sales_price_field'])&&$options['sales_price_field']=='2') echo 'selected'?>><?php _e('price 2','wooholo') ?></option>
                    <option value="3" <?php if(isset($_POST['sales_price_field'])&&$_POST['sales_price_field']=='3') echo 'selected'; else if(!isset($_POST['sales_price_field'])&&isset($options['sales_price_field'])&&$options['sales_price_field']=='3') echo 'selected'?>><?php _e('price 3','wooholo') ?></option>
                    <option value="4" <?php if(isset($_POST['sales_price_field'])&&$_POST['sales_price_field']=='4') echo 'selected'; else if(!isset($_POST['sales_price_field'])&&isset($options['sales_price_field'])&&$options['sales_price_field']=='4') echo 'selected'?>><?php _e('price 4','wooholo') ?></option>
                    <option value="5" <?php if(isset($_POST['sales_price_field'])&&$_POST['sales_price_field']=='5') echo 'selected'; else if(!isset($_POST['sales_price_field'])&&isset($options['sales_price_field'])&&$options['sales_price_field']=='5') echo 'selected'?>><?php _e('price 5','wooholo') ?></option>
                    <option value="6" <?php if(isset($_POST['sales_price_field'])&&$_POST['sales_price_field']=='6') echo 'selected'; else if(!isset($_POST['sales_price_field'])&&isset($options['sales_price_field'])&&$options['sales_price_field']=='6') echo 'selected'?>><?php _e('price 6','wooholo') ?></option>
                    <option value="7" <?php if(isset($_POST['sales_price_field'])&&$_POST['sales_price_field']=='7') echo 'selected'; else if(!isset($_POST['sales_price_field'])&&isset($options['sales_price_field'])&&$options['sales_price_field']=='7') echo 'selected'?>><?php _e('price 7','wooholo') ?></option>
                    <option value="8" <?php if(isset($_POST['sales_price_field'])&&$_POST['sales_price_field']=='8') echo 'selected'; else if(!isset($_POST['sales_price_field'])&&isset($options['sales_price_field'])&&$options['sales_price_field']=='8') echo 'selected'?>><?php _e('price 8','wooholo') ?></option>
                    <option value="9" <?php if(isset($_POST['sales_price_field'])&&$_POST['sales_price_field']=='9') echo 'selected'; else if(!isset($_POST['sales_price_field'])&&isset($options['sales_price_field'])&&$options['sales_price_field']=='9') echo 'selected'?>><?php _e('price 9','wooholo') ?></option>
                    <option value="10" <?php if(isset($_POST['sales_price_field'])&&$_POST['sales_price_field']=='10') echo 'selected'; else if(!isset($_POST['sales_price_field'])&&isset($options['sales_price_field'])&&$options['sales_price_field']=='10') echo 'selected'?>><?php _e('price 10','wooholo') ?></option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="special_price_field">
                    <?php _e('Special price field','wooholo')?>
                </label>
            </th>
            <td>
                <select class="" name="special_price_field">
                    <option value="1" <?php if(isset($_POST['special_price_field'])&&$_POST['special_price_field']=='1') echo 'selected'; else if(!isset($_POST['special_price_field'])&&isset($options['special_price_field'])&&$options['special_price_field']=='1') echo 'selected'?>><?php _e('price 1','wooholo') ?></option>
                    <option value="2" <?php if(isset($_POST['special_price_field'])&&$_POST['special_price_field']=='2') echo 'selected'; else if(!isset($_POST['special_price_field'])&&isset($options['special_price_field'])&&$options['special_price_field']=='2') echo 'selected'?>><?php _e('price 2','wooholo') ?></option>
                    <option value="3" <?php if(isset($_POST['special_price_field'])&&$_POST['special_price_field']=='3') echo 'selected'; else if(!isset($_POST['special_price_field'])&&isset($options['special_price_field'])&&$options['special_price_field']=='3') echo 'selected'?>><?php _e('price 3','wooholo') ?></option>
                    <option value="4" <?php if(isset($_POST['special_price_field'])&&$_POST['special_price_field']=='4') echo 'selected'; else if(!isset($_POST['special_price_field'])&&isset($options['special_price_field'])&&$options['special_price_field']=='4') echo 'selected'?>><?php _e('price 4','wooholo') ?></option>
                    <option value="5" <?php if(isset($_POST['special_price_field'])&&$_POST['special_price_field']=='5') echo 'selected'; else if(!isset($_POST['special_price_field'])&&isset($options['special_price_field'])&&$options['special_price_field']=='5') echo 'selected'?>><?php _e('price 5','wooholo') ?></option>
                    <option value="6" <?php if(isset($_POST['special_price_field'])&&$_POST['special_price_field']=='6') echo 'selected'; else if(!isset($_POST['special_price_field'])&&isset($options['special_price_field'])&&$options['special_price_field']=='6') echo 'selected'?>><?php _e('price 6','wooholo') ?></option>
                    <option value="7" <?php if(isset($_POST['special_price_field'])&&$_POST['special_price_field']=='7') echo 'selected'; else if(!isset($_POST['special_price_field'])&&isset($options['special_price_field'])&&$options['special_price_field']=='7') echo 'selected'?>><?php _e('price 7','wooholo') ?></option>
                    <option value="8" <?php if(isset($_POST['special_price_field'])&&$_POST['special_price_field']=='8') echo 'selected'; else if(!isset($_POST['special_price_field'])&&isset($options['special_price_field'])&&$options['special_price_field']=='8') echo 'selected'?>><?php _e('price 8','wooholo') ?></option>
                    <option value="9" <?php if(isset($_POST['special_price_field'])&&$_POST['special_price_field']=='9') echo 'selected'; else if(!isset($_POST['special_price_field'])&&isset($options['special_price_field'])&&$options['special_price_field']=='9') echo 'selected'?>><?php _e('price 9','wooholo') ?></option>
                    <option value="10" <?php if(isset($_POST['special_price_field'])&&$_POST['special_price_field']=='10') echo 'selected'; else if(!isset($_POST['special_price_field'])&&isset($options['special_price_field'])&&$options['special_price_field']=='10') echo 'selected'?>><?php _e('price 10','wooholo') ?></option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="wholesale_price_field">
                    <?php _e('Wholesale price field','wooholo')?>
                </label>
            </th>
            <td>
                <select class="" name="wholesale_price_field">
                    <option value="1" <?php if(isset($_POST['wholesale_price_field'])&&$_POST['wholesale_price_field']=='1') echo 'selected'; else if(!isset($_POST['wholesale_price_field'])&&isset($options['wholesale_price_field'])&&$options['wholesale_price_field']=='1') echo 'selected'?>><?php _e('price 1','wooholo') ?></option>
                    <option value="2" <?php if(isset($_POST['wholesale_price_field'])&&$_POST['wholesale_price_field']=='2') echo 'selected'; else if(!isset($_POST['wholesale_price_field'])&&isset($options['wholesale_price_field'])&&$options['wholesale_price_field']=='2') echo 'selected'?>><?php _e('price 2','wooholo') ?></option>
                    <option value="3" <?php if(isset($_POST['wholesale_price_field'])&&$_POST['wholesale_price_field']=='3') echo 'selected'; else if(!isset($_POST['wholesale_price_field'])&&isset($options['wholesale_price_field'])&&$options['wholesale_price_field']=='3') echo 'selected'?>><?php _e('price 3','wooholo') ?></option>
                    <option value="4" <?php if(isset($_POST['wholesale_price_field'])&&$_POST['wholesale_price_field']=='4') echo 'selected'; else if(!isset($_POST['wholesale_price_field'])&&isset($options['wholesale_price_field'])&&$options['wholesale_price_field']=='4') echo 'selected'?>><?php _e('price 4','wooholo') ?></option>
                    <option value="5" <?php if(isset($_POST['wholesale_price_field'])&&$_POST['wholesale_price_field']=='5') echo 'selected'; else if(!isset($_POST['wholesale_price_field'])&&isset($options['wholesale_price_field'])&&$options['wholesale_price_field']=='5') echo 'selected'?>><?php _e('price 5','wooholo') ?></option>
                    <option value="6" <?php if(isset($_POST['wholesale_price_field'])&&$_POST['wholesale_price_field']=='6') echo 'selected'; else if(!isset($_POST['wholesale_price_field'])&&isset($options['wholesale_price_field'])&&$options['wholesale_price_field']=='6') echo 'selected'?>><?php _e('price 6','wooholo') ?></option>
                    <option value="7" <?php if(isset($_POST['wholesale_price_field'])&&$_POST['wholesale_price_field']=='7') echo 'selected'; else if(!isset($_POST['wholesale_price_field'])&&isset($options['wholesale_price_field'])&&$options['wholesale_price_field']=='7') echo 'selected'?>><?php _e('price 7','wooholo') ?></option>
                    <option value="8" <?php if(isset($_POST['wholesale_price_field'])&&$_POST['wholesale_price_field']=='8') echo 'selected'; else if(!isset($_POST['wholesale_price_field'])&&isset($options['wholesale_price_field'])&&$options['wholesale_price_field']=='8') echo 'selected'?>><?php _e('price 8','wooholo') ?></option>
                    <option value="9" <?php if(isset($_POST['wholesale_price_field'])&&$_POST['wholesale_price_field']=='9') echo 'selected'; else if(!isset($_POST['wholesale_price_field'])&&isset($options['wholesale_price_field'])&&$options['wholesale_price_field']=='9') echo 'selected'?>><?php _e('price 9','wooholo') ?></option>
                    <option value="10" <?php if(isset($_POST['wholesale_price_field'])&&$_POST['wholesale_price_field']=='10') echo 'selected'; else if(!isset($_POST['wholesale_price_field'])&&isset($options['wholesale_price_field'])&&$options['wholesale_price_field']=='10') echo 'selected'?>><?php _e('price 10','wooholo') ?></option>
                </select>
                <p class="description">
                    <small>
                        <?php
                        $link = sprintf( wp_kses( __( 'You must install <a href="%s">this plugin</a> to use.', 'wooholo' ), array(  'a' => array( 'href' => array() ) ) ), esc_url( '/' ) );
                        echo $link;
                        ?>
                    </small>
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="product_stock_field">
                    <?php _e('Product stock field','wooholo')?>
                </label>
            </th>
            <td>
                <select class="" name="product_stock_field">
                    <option value="1" <?php if(isset($_POST['product_stock_field'])&&$_POST['product_stock_field']==='1') echo 'selected'; else if(!isset($_POST['product_stock_field'])&&isset($options['product_stock_field'])&&$options['product_stock_field']==='1') echo 'selected'?>><?php _e('Total stock','wooholo') ?></option>
                    <option value="2" <?php if(isset($_POST['product_stock_field'])&&$_POST['product_stock_field']==='2') echo 'selected'; else if(!isset($_POST['product_stock_field'])&&isset($options['product_stock_field'])&&$options['product_stock_field']==='2') echo 'selected'?>><?php _e('Inventory with retail deduction and pre-invoice','wooholo') ?></option>
                    <option value="3" <?php if(isset($_POST['product_stock_field'])&&$_POST['product_stock_field']==='3') echo 'selected'; else if(!isset($_POST['product_stock_field'])&&isset($options['product_stock_field'])&&$options['product_stock_field']==='3') echo 'selected'?>><?php _e('Inventory with retail deduction','wooholo') ?></option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="save_sale_invoice">
                    <?php _e('status sale invoice','wooholo')?>
                </label>
            </th>
            <td>
                <select  name="save_sale_invoice">
                    <option value="0" <?php if(isset($_POST['save_sale_invoice'])&&$_POST['save_sale_invoice']=='0') echo 'selected'; else if(!isset($_POST['save_sale_invoice'])&&isset($options['save_sale_invoice'])&&$options['save_sale_invoice']=='0') echo 'selected'?>>
                        <?php _e('Failure to register','wooholo');?>
                    </option>
                    <option value="1" <?php if(isset($_POST['save_sale_invoice'])&&$_POST['save_sale_invoice']=='1') echo 'selected'; else if(!isset($_POST['save_sale_invoice'])&&isset($options['save_sale_invoice'])&&$options['save_sale_invoice']=='1') echo 'selected'?>>
                        <?php _e('Invoice registration','wooholo');?>
                    </option>
                    <option value="2" <?php if(isset($_POST['save_sale_invoice'])&&$_POST['save_sale_invoice']=='2') echo 'selected'; else if(!isset($_POST['save_sale_invoice'])&&isset($options['save_sale_invoice'])&&$options['save_sale_invoice']=='2') echo 'selected'?>>
                        <?php _e('Pre-invoice registration','wooholo');?>
                    </option>
                    <option value="3" <?php if(isset($_POST['save_sale_invoice'])&&$_POST['save_sale_invoice']=='3') echo 'selected'; else if(!isset($_POST['save_sale_invoice'])&&isset($options['save_sale_invoice'])&&$options['save_sale_invoice']=='3') echo 'selected'?>>
                        <?php _e('Register as an order','wooholo');?>
                    </option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="save_pre_sale_invoice">
                    <?php _e('status pre sale invoice','wooholo')?>
                </label>
            </th>
            <td>
                <select name="save_pre_sale_invoice">
                    <option value="0" <?php if(isset($_POST['save_pre_sale_invoice'])&&$_POST['save_pre_sale_invoice']==0) echo 'selected'; elseif(!isset($_POST['save_pre_sale_invoice'])&&isset($options['save_pre_sale_invoice'])&&$options['save_pre_sale_invoice']==0) echo 'selected';?>>
                        <?php _e('Failure to register','wooholo');?>
                    </option>
                    <option value="1" <?php if(isset($_POST['save_pre_sale_invoice'])&&$_POST['save_pre_sale_invoice']==1) echo 'selected'; elseif(!isset($_POST['save_pre_sale_invoice'])&&isset($options['save_pre_sale_invoice'])&&$options['save_pre_sale_invoice']==1) echo 'selected';?>>
                        <?php _e('Invoice registration','wooholo');?>
                    </option>
                    <option value="2" <?php if(isset($_POST['save_pre_sale_invoice'])&&$_POST['save_pre_sale_invoice']==2) echo 'selected'; elseif(!isset($_POST['save_pre_sale_invoice'])&&isset($options['save_pre_sale_invoice'])&&$options['save_pre_sale_invoice']==2) echo 'selected';?>>
                        <?php _e('Pre-invoice registration','wooholo');?>
                    </option>
                    <option value="3" <?php if(isset($_POST['save_pre_sale_invoice'])&&$_POST['save_pre_sale_invoice']==3) echo 'selected'; elseif(!isset($_POST['save_pre_sale_invoice'])&&isset($options['save_pre_sale_invoice'])&&$options['save_pre_sale_invoice']==3) echo 'selected';?>>
                        <?php _e('Register as an order','wooholo');?>
                    </option>
                </select>
            </td>
        </tr>
        </tbody>
    </table>
    <?php
    wp_nonce_field( 'woo_holo_save_main_nonce', 'woo_holo_main_nonce' );

    submit_button( __('Save Change','wooholo'), 'primary', 'woo_holo_save_main', true );
    ?>
</form>
