<?php


namespace WOOHolo;


class Enqueue
{
    private $options;
    private $server_url;
    public function __construct()
    {
        $this->options= get_option( 'woo_holo' );
        $this->server_url=isset($this->options['server_url'])&&$this->options['server_url']!='' ? $this->options['server_url'] : WOOHOLOSERVER_URL;

        add_action( 'admin_enqueue_scripts', array($this, 'woo_holo_admin_add_enqueue') );
    }
    /*
     * add style.css to admin wordpress
     */
    function woo_holo_admin_add_enqueue($hook){
        wp_enqueue_style('holo-style',WOOHOLO_URI.'assets/css/style.css',false,false);

        if ( 'toplevel_page_woo-holo' != $hook ) {
            return;
        }
        wp_enqueue_script('jquery3.2.1',WOOHOLO_URI.'assets/js/jquery.min.js');
        wp_enqueue_style('bootstrap',WOOHOLO_URI.'assets/css/bootstrap.min.css');
        wp_enqueue_script('bootstrap',WOOHOLO_URI.'assets/js/bootstrap.min.js');
        wp_enqueue_script('select2.min',WOOHOLO_URI.'assets/js/select2.min.js');
        wp_enqueue_style('select2.min',WOOHOLO_URI.'assets/css/select2.min.css');
        wp_enqueue_style('dataTables',WOOHOLO_URI.'assets/css/jquery.dataTables.min.css');
        wp_enqueue_script('dataTables',WOOHOLO_URI.'assets/js/jquery.dataTables.min.js');
        wp_enqueue_script('wooholo',WOOHOLO_URI.'assets/js/wooholo.js',false,false);
        wp_localize_script(
            'wooholo',
            'wooholo_ajax_obj',
            array(
                'ajaxurl' => admin_url( 'admin-ajax.php' ),
                'WOOHOLOSERVER_URL' => $this->server_url,
                'nonce' => wp_create_nonce('ajax-nonce')
            )
        );
    }
}