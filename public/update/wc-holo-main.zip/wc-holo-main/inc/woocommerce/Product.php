<?php
namespace WOOHolo\woocommerce;
use WOOHolo\Admin\Action;
use WOOHolo\admin\GetWay;
use function DI\get;

class Product
{
    function __construct()
    {
             
        /**
         * Add Holo Sku Field to Product
        */
        add_action('woocommerce_product_options_sku', array($this,'woo_holo_woocommerce_product_holo_sku_fields'));
        add_action('woocommerce_variation_options_pricing', array($this,'woo_holo_woocommerce_product_variation_holo_sku_fields'),10,3);
        add_action('woocommerce_process_product_meta', array($this,'woo_holo_woocommerce_product_simple_holo_sku_fields_save'));
        add_action('woocommerce_save_product_variation', array($this,'woo_holo_woocommerce_product_variation_holo_sku_fields_save'),10,2);
        /**
         * Add Holo Sku To Products Table Column
         */
        add_filter( 'manage_edit-product_columns', array($this,'woo_holo__admin_products_holo_sku_column'), 10 );
        add_action( 'manage_product_posts_custom_column', array($this,'woo_holo_admin_products_holo_sku_column_content'), 10, 2 );
        /**
         *    sending product data to holo in update product - WooCommerce
         */
        add_action( 'save_post_product', array($this, 'woo_holo_update_product' ), 999, 3);
    }
    /**
     * add  Holo Sku field to woocommerce simple product
     *
     */
    function woo_holo_woocommerce_product_holo_sku_fields()
    {
        echo '<div class="options_group show_if_simple hide_if_variable show_if_grouped show_if_external">';
        //  Holo Code Product Text Field
        woocommerce_wp_text_input(
            array(
                'id' => '_holo_sku',
                'placeholder' => __('holo sku','wooholo'),
                'label' => __('holo sku', 'wooholo'),
                'value' => get_post_meta( get_the_id(), '_holo_sku', true ),
                'desc_tip' => 'true',
                'description'=>__('Product Id in Holo Software.','wooholo'),
                'class'    =>'short'
            )
        );
        echo '</div>';
    }

    /**
     * save  Holo Sku field to woocommerce simple product
     *
     */
    function woo_holo_woocommerce_product_simple_holo_sku_fields_save($post_id)
    {
        // Save Holo Sku Product Text Field
        update_post_meta($post_id, '_holo_sku',$_POST['_holo_sku'] ? $_POST['_holo_sku'] : '');
    }
   
     /**
     * add  Holo Sku field to woocommerce variation product
     *
     */
    function woo_holo_woocommerce_product_variation_holo_sku_fields($loop, $variation_data, $variation ) {
        echo '<div class="form-row show_if_variable">';
           woocommerce_wp_text_input( array(
            'id' => '_holo_sku[' . $loop . ']',
            'class' => 'short',
            'label' => __('holo sku', 'wooholo'),
            'value' => get_post_meta( $variation->ID, '_holo_sku', true ),
            'desc_tip' => 'true',
            'description'=>__('Product Id in Holo Software.','wooholo'),
               ) );
         echo '</div>';
    }

    /**
     * save  Holo Sku field to woocommerce variation product
     *
     */
    function woo_holo_woocommerce_product_variation_holo_sku_fields_save($variation_id, $i)
    {
        update_post_meta( $variation_id, '_holo_sku', $_POST['_holo_sku'][$i] ? $_POST['_holo_sku'][$i] : '' );
    }
    
    function woo_holo__admin_products_holo_sku_column($columns){
    
        $columns=array_slice( $columns, 0, 4, true ) + array( 'holo_sku' => __('holo sku','wooholo') ) + array_slice( $columns, 4, count( $columns ) - 4, true );
        $columns=array_slice( $columns, 0, 5, true ) + array( 'update_date_holo' => __('update date holo','wooholo') ) + array_slice( $columns, 5, count( $columns ) - 5, true );
        return $columns;
    }
    function woo_holo_admin_products_holo_sku_column_content( $column, $product_id){
        if ( $column == 'holo_sku' ) {
            echo get_post_meta( $product_id, '_holo_sku', true );
        }
        if ( $column == 'update_date_holo' ) {
            echo get_post_meta( $product_id, '_update_date_holo', true );
        }
    }
      /**
     * update holo_code in woocommerce product
     */

    public function update_holo_code($product_id,$holo_id){
        (new Action())->woo_holo_log("Update Product woocommerce: product_id::$product_id holocode::$holo_id");
        update_post_meta($product_id,'_holo_sku',$holo_id);
    }

    function woo_holo_update_product( $post_ID, $post, $update){
        $is_new = $post->post_date === $post->post_modified;
        if ( wp_is_post_revision( $post_ID ) ) {
            return;
        }
        if (!$product = wc_get_product( $post )) {
            return;
        }
        if(!$is_new&&$update) {
            $response = (new GetWay)->connection('changeProduct', (array)$product);
            if (isset($response->responseCode) && $response->responseCode == 200) {
                (new Action())->woo_holo_log("Successful sending of product($post_ID) to holo after update::responseCode: $response->responseCode ::responseMessage: $response->message");
            } else {
                (new Action())->woo_holo_log("error in sending of product($post_ID) to holo after update::responseCode: $response->responseCode ::responseMessage: $response->message");
            }
        }
    }
}