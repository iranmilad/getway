<?php

/*
 * The plugin bootstrap file
 *
 * Plugin Name:       Woo Holo
 * Plugin URI:        n/a
 * Description:       Connect holo software with WooCommerce plugin
 * Version:           1.9.9
 * Author:            holooideh
 * Author URI:        https://holooideh.com
 * License:           GPL-2.0+
 * License URI:       n/a
 * Text Domain:       wooholo
 * Domain Path:       /languages
 *
 */

if( ! defined('ABSPATH') ) {
    return;
}
if(file_exists(dirname(__FILE__).'/vendor/autoload.php')){
    require_once dirname(__FILE__).'/vendor/autoload.php';
}
if(file_exists(dirname(__FILE__).'/Update_Plugin.php')){
    require_once dirname(__FILE__).'/Update_Plugin.php';
}
new Update_Plugin(
    'https://laravel.clawar-services.org/update/wooholo-update.json',
    plugin_basename(__FILE__),
    __FILE__, //Full path to the main plugin file or functions.php.
    'wc-holo-main'
);
/*
 * textdomain
 *
 */
if( ! function_exists('woo_holo_load_textdomain')) {
    function woo_holo_load_textdomain() {
        load_plugin_textdomain('wooholo', false, basename( dirname( __FILE__ ) ) . '/languages');
    }
    add_action('init', 'woo_holo_load_textdomain');
}
/*
 * const
 *
 */
define('WOOHOLO_PLUGIN', __FILE__ );
define('WOOHOLO_PATH', wp_normalize_path( plugin_dir_path( __FILE__ ) . DIRECTORY_SEPARATOR ));
define('WOOHOLO_URI', plugin_dir_url( __FILE__ ));
define('WOOHOLO_VERSION', '1.0.0');

/*
 * const server
 *
 */
define('WOOHOLOSERVER_URL','https://www.laravel.clawar-services.org');
define('WOOHOLOSERVER_VALIDATE',['wcGetExcelProducts','wcAddAllHolooProductsCategory','updateAllProductFromHolooToWC','getProductConflict','wcSingleProductUpdate']);
define('WOOHOLOSERVER_GETKEY','#');
register_activation_hook(__FILE__, array(new WOOHolo\admin\Activate(), "active"));

new WOOHolo\admin\Menu();
new WOOHolo\Check_Setting();
new WOOHolo\woocommerce\Product();
new WOOHolo\woocommerce\Order();
new WOOHolo\Enqueue();
new WOOHolo\Api();
new WOOHolo\woocommerce\Rest_api();
new WOOHolo\admin\Action();
new WOOHolo\admin\Ajax;
