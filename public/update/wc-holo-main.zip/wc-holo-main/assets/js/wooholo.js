jQuery(document).ready(function() {
    var current_url = new URL(window.location.href);
    var tab = current_url.searchParams.get("tab");
    if(tab=='licence'){
         jQuery.ajax({
            type:'POST',
            url:wooholo_ajax_obj.ajaxurl,
            data: {
                'action': 'woo_holo',
                'endpoint':'user-profile',
                'nonce' : wooholo_ajax_obj.nonce
            },
            beforeSend:function () {
                jQuery('#woo_holo_save_licence').css({'pointer-events':'none','opacity': 0.4});
                jQuery('.loader').css('display','flex');

            },
            success:function (data) {
                data = jQuery.parseJSON(data);
                if (data.responseCode === 200) {
                    if (data.response){
                       html = '<div class="alert alert-success" role="alert">'+data.message+'</div>';
                       jQuery('.loginstatus').html(html);
                    }
                    else {
                        html = '<div class="alert alert-danger" role="alert">'+data.message+'</div>';
                        jQuery('.loginstatus').html(html);
                    }
                }
                else {
                    html = '<div class="alert alert-danger" role="alert">'+data.message+'</div>';
                    jQuery('.loginstatus').html(html);
                }
            },
            error: function (request, status, error) {
                html = '<div class="alert alert-danger" role="alert">'+error+'</div>';
                jQuery('.match').html(html);
            },
            complete:function () {
                jQuery('#woo_holo_save_licence').css({'pointer-events':'unset','opacity': 1});
                jQuery('.loader').css('display','none');


            }
        });
    }
    if(tab=='no_match'){
        jQuery.ajax({
            type:'POST',
            url:wooholo_ajax_obj.ajaxurl,
            data: {
                'action': 'woo_holo',
                'endpoint':'getProductConflict',
                'nonce' : wooholo_ajax_obj.nonce
            },
            beforeSend:function () {
                jQuery('.match').addClass('shimmer');
                jQuery('#ploading,.match').show();

            },
            success:function (data) {
                data = jQuery.parseJSON(data);
                if (data.responseCode === 200) {
                    if (Object.keys(data.response.result).length !== 0){
                        var dataTable= jQuery('#woholoTabel').DataTable({
                            "processing": true,
                            "language": getLanguage(),
                            "aaData": data.response.result,
                            "aoColumns": [
                                {'mData': 'woocommerce_product_id'},
                                {'mData': 'product_name'},
                                {'mData': 'amount'},
                                {'mData': 'price'},
                                {
                                    'mData': 'holo_code',
                                    sortable: false,
                                    "render": function (data, type, full, meta) {
                                        if ($.inArray(3, full.msg_code) !== -1) {
                                            hc = '<p>';
                                            hc += '<input value="' + data + '" name="holo_code"/>';
                                            hc += '</p>';
                                            hc += '<a data-wcid="' + full.woocommerce_product_id + '" class="holoCodeUpdate"><span class="dashicons dashicons-update-alt"></a>';
                                            return hc;
                                        } else {
                                            return data;
                                        }
                                    }
                                },
                                {
                                    'mData': 'msg',

                                    sortable: false,
                                    "render": function (data, type, full, meta) {
                                        var ms = '<ul>';
                                        for (var i in full.msg) {
                                            var msg = full.msg;
                                            ms += '<li>' + msg[i] + '</li>';
                                        }
                                        ms += '</ul>';
                                        return ms;
                                    }
                                },
                                {

                                    'mData': 'msg_code',
                                    sortable: false,
                                    "render": function (data, type, full, meta) {
                                        if ($.inArray(2, full.msg_code) !== -1 || $.inArray(1, full.msg_code) !== -1 || $.inArray(0, full.msg_code) !== -1) {
                                            return '<button data-holoid="' + full.holo_code + '" data-wcid="' + full.woocommerce_product_id + '" class="updatePr"><span class="dashicons dashicons-update-alt"></button>';
                                        } else {
                                            return '';
                                        }

                                    }

                                },

                            ]
                        });
                    }
                    else {
                        html = '<div class="alert alert-danger" role="alert">'+data.message+'</div>';
                        jQuery('.match').html(html);
                    }
                }
                else {
                    html = '<div class="alert alert-danger" role="alert">'+data.message+'</div>';
                    jQuery('.match').html(html);
                }
            },
            error: function (request, status, error) {
                html = '<div class="alert alert-danger" role="alert">'+error+'</div>';
                jQuery('.match').html(html);
            },
            complete:function () {
                jQuery('.match').removeClass('shimmer');
                jQuery('#ploading').hide();
            }
        });
        $('#woholoTabel').on('click','.holoCodeUpdate', function(e)
        {
            e.stopPropagation();
            var wcId=$(this).attr('data-wcid');
            var holoId=$(this).parent().find('input[name="holo_code"]').val();
            jQuery.ajax({
                type:'POST',
                url:wooholo_ajax_obj.ajaxurl,
                data: {
                    'action': 'woo_holo',
                    'endpoint':'',
                    'product_id' : wcId,
                    'holoo_id' : holoId,
                    'nonce' : wooholo_ajax_obj.nonce
                },
                beforeSend:function () {
                    jQuery('.match').addClass('shimmer');
                    jQuery('#ploading,.match').show();

                },
                success:function (data) {
                    alert(data);
                    window.location.reload();
                },
                error: function (request, status, error) {
                    html = '<div class="alert alert-danger" role="alert">'+error+'</div>';
                    jQuery('.match').html(html);
                },
                complete:function () {
                    jQuery('.match').removeClass('shimmer');
                    jQuery('#ploading').hide();
                }
            });

        });
        $('#woholoTabel').on('click','.updatePr', function(e)
        {
            e.stopPropagation();
            var wcId=$(this).attr('data-wcid');
            var holoId=$(this).attr('data-holoid');
            jQuery.ajax({
                type:'POST',
                url:wooholo_ajax_obj.ajaxurl,
                data: {
                    'action': 'woo_holo',
                    'endpoint':'wcSingleProductUpdate',
                    'product_id' : wcId,
                    'holoo_id' : holoId,
                    'nonce' : wooholo_ajax_obj.nonce
                },
                beforeSend:function () {
                    jQuery('.match').addClass('shimmer');
                    jQuery('#ploading,.match').show();

                },
                success:function (data) {
                    data = jQuery.parseJSON(data);
                    if (data.responseCode === 200) {
                        alert(data.message);
                        window.location.reload();
                    }
                    else {
                        html = '<div class="alert alert-danger" role="alert">'+data.message+'</div>';
                        jQuery('.match').html(html);
                    }
                },
                error: function (request, status, error) {
                    html = '<div class="alert alert-danger" role="alert">'+error+'</div>';
                    jQuery('.match').html(html);
                },
                complete:function () {
                    jQuery('.match').removeClass('shimmer');
                    jQuery('#ploading').hide();
                }
            });

        });
    }
    var langMap = {
        en: {
            path: 'en',
            mods: {
                sLengthMenu: "Display _MENU_ records per page - custom test"
            }
        },
        fa: {
            path: 'fa',
            mods: {
                sLengthMenu: "نمایش رکوردهای یافت شده"
            }
        }
    };
    function getLanguage() {
    
        var lang = jQuery('html').attr('lang').split('-')[0];
        var path = '//cdn.datatables.net/plug-ins/1.11.5/i18n/';
        var result = null;
        jQuery.ajax({
            async: false,
            url: path + lang + '.json',
            success: function(obj) {
                result = $.extend({}, obj, langMap[lang].mods);
            }
        });
        return result;
    }
    jQuery('#tgexport').on('click', function() {
        jQuery('.box-export').toggle();
    });
    jQuery('body').on('click','#export-holo-product',function (e){
        e.preventDefault();
        jQuery.ajax({
            type:'POST',
            url:wooholo_ajax_obj.ajaxurl,
            data: {
                'action': 'woo_holo',
                'endpoint':'wcGetExcelProducts',
                'nonce' : wooholo_ajax_obj.nonce
            },
            beforeSend:function () {
                jQuery('#export-holo-product').css({'pointer-events':'none','opacity': 0.4});
                jQuery('#export-holo-product').parent().find('.loader').css('display','flex');
                jQuery('#result').append('').hide();
            },
            success:function (data) {
                data = jQuery.parseJSON(data);
                if (data.responseCode === 200) {
                    var result=data.response.result;
                    if(result){
                        jQuery('#btn-export').attr('href',result.url);
                        jQuery('#result').show();
                    }
                }
                else {
                    jQuery('#result').append(data.massege).show();
                }

            },
            complete:function () {
                jQuery('#export-holo-product').css({'pointer-events':'unset','opacity': 1});
                jQuery('#export-holo-product').parent().find('.loader').css('display','none');
            }
        });


    });
    jQuery('body').on('click','#getCategories',function (e){
        e.preventDefault();
        jQuery.ajax({
            type:'POST',
            url:wooholo_ajax_obj.ajaxurl,
            data: {
                'action': 'woo_holo',
                'endpoint':'getProductCategory',
                'nonce' : wooholo_ajax_obj.nonce
            },
            beforeSend:function () {
                jQuery('#getCategories').parent().find('input[type="submit"]').css({'pointer-events':'none','opacity': 0.4});
                jQuery('#getCategories').parent().find('.loader').css('display','flex');
            },
            success:function (data) {
                data = jQuery.parseJSON(data);
                alert(data.message);

            },
            error: function (request, status, error) {
                alert(error);
            },
            complete:function () {
                jQuery('#getCategories').parent().find('input[type="submit"]').css({'pointer-events':'unset','opacity': 1});
                jQuery('#getCategories').parent().find('.loader').css('display','none');
            }
        });
    });
    jQuery('body').on('click','#getProducts',function (e){
        e.preventDefault();
        jQuery.ajax({
            type:'POST',
            url:wooholo_ajax_obj.ajaxurl,
            data: {
                'action': 'woo_holo',
                'endpoint':'wcAddAllHolooProductsCategory',
                'nonce' : wooholo_ajax_obj.nonce
            },
            beforeSend:function () {
                jQuery('#getProducts').parent().find('input[type="submit"]').css({'pointer-events':'none','opacity': 0.4});
                jQuery('#getProducts').parent().find('.loader').css('display','flex');
            },
            success:function (data) {
                data = jQuery.parseJSON(data);
                alert(data.message);

            },
            error: function (request, status, error) {
                alert(error);
            },
            complete:function () {
                jQuery('#getProducts').parent().find('input[type="submit"]').css({'pointer-events':'unset','opacity': 1});
                jQuery('#getProducts').parent().find('.loader').css('display','none');
            }
        });
    });
    jQuery('body').on('click','#updateProducts',function (e){
        e.preventDefault();
        jQuery.ajax({
            type:'POST',
            url:wooholo_ajax_obj.ajaxurl,
            data: {
                'action': 'woo_holo',
                'endpoint':'updateAllProductFromHolooToWC',
                'nonce' : wooholo_ajax_obj.nonce
            },
            beforeSend:function () {
                jQuery('#updateProducts').parent().find('input[type="submit"]').css({'pointer-events':'none','opacity': 0.4});
                jQuery('#updateProducts').parent().find('.loader').css('display','flex');
            },
            success:function (data) {
                data = jQuery.parseJSON(data);
                alert(data.message);
            },
            error: function (request, status, error) {
                alert(error);
            },
            complete:function () {
                jQuery('#updateProducts').parent().find('input[type="submit"]').css({'pointer-events':'unset','opacity': 1});
                jQuery('#updateProducts').parent().find('.loader').css('display','none');
            }
        });
    });
} );
