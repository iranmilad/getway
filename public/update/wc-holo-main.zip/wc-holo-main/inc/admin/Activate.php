<?php

namespace WOOHolo\admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
if(!class_exists("Activate")) {
    class Activate
    {
        public function __construct()
        {

        }

        public function active()
        {
            /*
             * check woocommerce plugin is active or deActive
             */
            if( !class_exists( 'WooCommerce' ) ) {
                deactivate_plugins( plugin_basename( __FILE__ ) );
                wp_die( __( 'Please install and Activate WooCommerce.', 'wooholo' ), 'Plugin dependency check', array( 'back_link' => true ) );
            }
            else{
                /*
                 * add 10 days schedules in wordpress
                 */
                add_filter('cron_schedules', array($this, 'woo_holo_cron_time_intervals'));
                /*
                 * add hook for 10 days schedules
                 */
                add_action( 'init',  array($this, 'woo_holo_cron_scheduler'));
            }
        }
        public function woo_holo_cron_time_intervals($schedules)
        {
            if(! isset($schedules['10_Days'])){
                $schedules['10_Days'] = array(
                    'interval' => 10 * 24 * 60 * 60,
                    'display' => 'Once 10 Days'
                );
            }
            return $schedules;
        }
        function woo_holo_cron_scheduler() {
            if ( ! wp_next_scheduled( 'woo_holo_remove_file_log' ) ) {
                wp_schedule_event( time(), '10_Days', 'woo_holo_remove_file_log');
            }
        }
    }
}