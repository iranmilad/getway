<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
?>
<table class="form-table">
        <tbody>
        <tr>
            <th scope="row"><?php _e('Access status of holo software','wooholo')?></th>
            <td>
                <p class="holo-status">
                    <?php
                    if(isset($options['holo_status'])&&$options['holo_status']=='ok'&&$options['holo_token_expires_in']-time()>0){
                        echo '<span class="status-success">'.__('Holo Available', 'wooholo').'</span>';
                    }
                    else{
                        echo '<span class="status-error">'.__('Holo Not Available', 'wooholo').'</span>';
                        echo '<p>'.date('Y/m/d H:i:s',$options['holo_token_expires_in']).'</p>';
                    }
                    ?>
                </p>
                <textarea class="holo-token" rows="5" cols="50" disabled>
                    <?php
                    if(isset($options['holo_status'])&&$options['holo_status']=='ok'&&isset($options['holo_token'])&&$options['holo_token_expires_in']-time()>0){
                        echo $options['holo_token'];
                    }
                    ?>
                </textarea>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php _e('Get categories and products','wooholo');?></th>
            <td>
                <input type="submit" id="updateProducts" value="<?php _e('Update Products','wooholo') ?>">
                <input type="submit" id="getCategories" value="<?php _e('Get Categories','wooholo') ?>">
                <input type="submit" id="getProducts" value="<?php _e('Get Products','wooholo') ?>">
                <div class="loader">
                                      
                    <p><?php _e('Please do not refresh the page until the request is complete or send a new request.','wooholo')?></p>

                    <div class="sk-circle ">
                        <div class="sk-circle1 sk-child"></div>
                        <div class="sk-circle2 sk-child"></div>
                        <div class="sk-circle3 sk-child"></div>
                        <div class="sk-circle4 sk-child"></div>
                        <div class="sk-circle5 sk-child"></div>
                        <div class="sk-circle6 sk-child"></div>
                        <div class="sk-circle7 sk-child"></div>
                        <div class="sk-circle8 sk-child"></div>
                        <div class="sk-circle9 sk-child"></div>
                        <div class="sk-circle10 sk-child"></div>
                        <div class="sk-circle11 sk-child"></div>
                        <div class="sk-circle12 sk-child"></div>
                    </div>
                </div>
            </td>
        </tr>
        </tbody>
</table>
<span id="tgexport"><?php _e('I need product export','wooholo')?></span>
<div class="box-export">
    <button class="btn btn-default" id="export-holo-product"><?php _e('Get output list of all holo products','wooholo') ?></button>
    <div id="result">
        <p><?php _e('The file is ready to download, click on the link below.','wooholo'); ?></p>
        <a id="btn-export" href=""><?php _e('export','wooholo');?></a>
    </div>
    <div class="loader">
        <p><?php _e('We are receiving products from holo software and preparing the output file. Please do not refresh the page and wait.','wooholo')?></p>
        <div class="sk-circle ">
            <div class="sk-circle1 sk-child"></div>
            <div class="sk-circle2 sk-child"></div>
            <div class="sk-circle3 sk-child"></div>
            <div class="sk-circle4 sk-child"></div>
            <div class="sk-circle5 sk-child"></div>
            <div class="sk-circle6 sk-child"></div>
            <div class="sk-circle7 sk-child"></div>
            <div class="sk-circle8 sk-child"></div>
            <div class="sk-circle9 sk-child"></div>
            <div class="sk-circle10 sk-child"></div>
            <div class="sk-circle11 sk-child"></div>
            <div class="sk-circle12 sk-child"></div>
        </div>
    </div>
</div>
