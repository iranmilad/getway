<?php


namespace WOOHolo;


class Enqueue
{
    function __construct()
    {
        add_action( 'admin_enqueue_scripts', array($this, 'woo_holo_admin_add_enqueue') );
    }
    /*
     * add style.css to admin wordpress
     */
    function woo_holo_admin_add_enqueue($hook){
        wp_enqueue_style('holo-style',WOOHOLO_URI.'assets/css/style.css');
       
        if ( 'toplevel_page_woo-holo' != $hook ) {
            return;
        }
        wp_enqueue_style('bootstrap',WOOHOLO_URI.'assets/css/bootstrap.min.css');
        wp_enqueue_script('bootstrap',WOOHOLO_URI.'assets/js/bootstrap.min.js');
        wp_enqueue_script('jquery3.2.1',WOOHOLO_URI.'assets/js/jquery.min.js');
        wp_enqueue_style('dataTables',WOOHOLO_URI.'assets/css/jquery.dataTables.min.css');
        wp_enqueue_script('dataTables',WOOHOLO_URI.'assets/js/jquery.dataTables.min.js');
        wp_enqueue_script('wooholo',WOOHOLO_URI.'assets/js/wooholo.js',false);
        wp_localize_script(
		'wooholo',
		'wooholo_ajax_obj',
    		array(
    			'ajaxurl' => admin_url( 'admin-ajax.php' ),
    			'WOOHOLOSERVER_URL' => WOOHOLOSERVER_URL,
    			'nonce' => wp_create_nonce('ajax-nonce')
    		)
        );
    }
}