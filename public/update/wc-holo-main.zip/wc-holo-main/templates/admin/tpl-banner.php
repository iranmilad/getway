<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
do_action('before_holo_banner');?>
<div class="holo-banner">
    <a href="https://holoostore.com/product/%d8%a7%d9%81%d8%b2%d9%88%d9%86%d9%87-%d8%a7%d8%b1%d8%aa%d8%a8%d8%a7%d8%b7-%d9%81%d8%b1%d9%88%d8%b4%da%af%d8%a7%d9%87-%d8%a7%db%8c%d9%86%d8%aa%d8%b1%d9%86%d8%aa%db%8c-%d9%86%db%8c%d9%84%d8%a7">
        <img style="width: 100%;" alt="holo banner" src="https://www.holooideh.com/wp-content/uploads/2020/06/nilla-banner.png"/>
    </a>
</div>
<?php do_action('after_holo_banner');?>
