<?php
namespace WOOHolo\admin;
use WOOHolo\admin\Menu;
use WOOHolo\admin\Action;
class GetWay
{
    function __construct()
    {


    }

    /*
     * check login with holo
     */
    public function login($licence){
        $url = $this->get_site_url_ssl();
        try {
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => WOOHOLOSERVER_URL.'/api/login',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => array('siteUrl' => $url,'activeLicense' => $licence),
            ));
            $response = curl_exec($curl);
            curl_close($curl);
            $data =  json_decode($response);
            return $data;
        }
        catch (\Exception $exception){
            return 0;
        }
    }
    /*
    * connect with getWay
    */
    public function connection($endpoint,$data_getway=[]){
        $options=get_option('woo_holo');
        $token=$options['holo_token'];
        $result= json_encode($data_getway+$options);
        $response = wp_remote_post( WOOHOLOSERVER_URL.'/api/'.$endpoint,
            array(
                'timeout'     => 36000,
                'httpversion' => '1.1',
                'method'      => 'POST',
                'blocking' => true,
                'headers'     => array(
                    'Authorization' => 'Bearer ' . $token,
                    'content-type' => 'application/json'
                ),
                'body'=>$result
            )
        );
        if ( is_array( $response ) && ! is_wp_error( $response ) ) {
            $data = json_decode(wp_remote_retrieve_body($response));
            if($data->responseCode!=200){
                if($token){
                  return  $this->get_new_token($endpoint,$data_getway,$token);
                }
                else{
                    (new Action())->woo_holo_log('Error! The license key is invalid::responseCode: '.$data->responseCode.'::responsMessage: '.$data->message);
                     return array('message'=>__('The license key is invalid','wooholo'));
                }
            }
            else{
                 (new Action())->woo_holo_log('Success! '.$endpoint.' root::responseCode: '.$data->responseCode.'::responsMessage: '.$data->message);
                 return $data;
            }
        } 
        else {
                (new Action())->woo_holo_log('Error! In response 500 ::responsMessage: '.json_encode($response));
                return array('message'=>__('Error Connection to Getway','wooholo'));
        }
    }
    function get_new_token($endpoint,$data_getway,$current_token){
        $response = wp_remote_post( WOOHOLOSERVER_URL.'/api/refresh',
        array(
            'timeout'     => 720,
            'httpversion' => '1.1',
            'blocking' => true,
            'method'      => 'POST',
             'headers'     => array(
                'Authorization' => 'Bearer ' . $current_token,
            ),
        )
        );
        if ( is_array( $response ) && ! is_wp_error( $response ) ) {
            $data = json_decode(wp_remote_retrieve_body($response));
            if($data->responseCode==200){
                if(isset($data->response->token)){
                    (new Menu())->woo_holo_update_option( 'holo_token', false ,false,$data->response->token);
                    (new Action())->woo_holo_log('Success! get new token in refresh root::responseCode: '.$data->responseCode.'::responsMessage: '.$data->message);
                    return  $this->connection($endpoint,$data_getway);
                }
                else{
                    (new Action())->woo_holo_log('Error! get new token in refresh root::responseCode: '.$data->responseCode.'::responsMessage: '.$data->message);
                    return $data;
                }
            }
            else{
               (new Action())->woo_holo_log('Error! get new token in refresh root::responseCode: '.$data->responseCode.'::responsMessage: '.$data->message);
                return $data;
            }
        } else {
            (new Action())->woo_holo_log('Error! response 500 in refresh root ::responsMessage: '.json_encode($response));
            return array('message'=>__('Error! connection to refresh root','wooholo'));
        }
    }
    function get_site_url_ssl() {
       $protocols = array( 'http://', 'https://');
       return str_replace( $protocols, 'https://', site_url() );
    }
}