<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );

 if(count($options['holo_categories'])==0){
    echo '<div class="alert alert-danger m-10">'.__('import category in general tab.', 'wooholo').'</div>';
    return;
}
function woo_holo_all_category($options,$name_field)
{
    $html='';
    $parent_cat_arg = array('hide_empty' => false, 'parent' => 0);
    $parent_categories = get_terms('product_cat', $parent_cat_arg);
    foreach ($parent_categories as $category) {
        $select='';
        if (isset($_POST['product_cat'][$name_field]) ) {
            if ($_POST['product_cat'][$name_field] == $category->term_id){
                $select = "selected";
            }
        }
        else if(isset($options['product_cat'][$name_field]) && $options['product_cat'][$name_field] == $category->term_id)
        {
            $select = "selected";
        }
        $html .='<option value="' . $category->term_id . '" ' . $select . '>' . $category->name . '</option>'; //Parent Category
        $child_arg = array('hide_empty' => false, 'parent' => $category->term_id);
        $child_cat = get_terms('product_cat', $child_arg);
        foreach ($child_cat as $child_term) {
            $select_1='';
            if (isset($_POST['product_cat'][$name_field])) {
                if($_POST['product_cat'][$name_field] == $child_term->term_id ) {
                    $select_1 = "selected";
                }
            }
            else if(isset($options['product_cat'][$name_field]) && $options['product_cat'][$name_field] == $child_term->term_id)
            {
                $select_1 = "selected";
            }
            $html .= '<option value="' . $child_term->term_id . '" ' . $select_1 . '>-' . $child_term->name . '</option>'; //Parent Category
            $child2_arg = array('hide_empty' => false, 'parent' => $child_term->term_id);
            $child2_cat = get_terms('product_cat', $child2_arg);
            foreach ($child2_cat as $child2_term) {
                $select_2='';
                if (isset($_POST['product_cat'][$name_field])) {
                    if ($_POST['product_cat'][$name_field] == $child2_term->term_id) {
                        $select_2 = "selected";
                    }
                }
                else if(isset($options['product_cat'][$name_field]) && $options['product_cat'][$name_field] == $child2_term->term_id)
                {
                    $select_2 = "selected";
                }
                $html .= '<option value="' . $child2_term->term_id . '" ' . $select_2 . '>--' . $child2_term->name . '</option>'; //Parent Category
            }
        }
    }
    return $html;
}
?>
<form method="post">
    <table class="form-table">
        <tbody>
        <?php
        if(isset($options['holo_categories'])&&!empty($options['holo_categories'])){
            foreach ($options['holo_categories'] as $holo_category){
                ?>
                <tr>
                    <th scope="row">
                        <label for="product_cat_<?php echo $holo_category->m_groupcode; ?>">
                            <?php echo $holo_category->m_groupname; ?>
                        </label>
                    </th>
                    <td>
                        <select class="" name="product_cat[<?php echo $holo_category->m_groupcode; ?>]">
                            <option value=""><?php _e("not save",'wooholo');?></option>
                            <?php echo woo_holo_all_category($options,$holo_category->m_groupcode);?>
                        </select>
                    </td>
                </tr>
            <?php }
        }
        ?>
        </tbody>
    </table>
    <?php

    wp_nonce_field( 'woo_holo_save_product_category_nonce', 'woo_holo_product_category_nonce' );

    submit_button( __('Save Change','wooholo'), 'primary', 'woo_holo_save_product_category', true );
    ?>
</form>
