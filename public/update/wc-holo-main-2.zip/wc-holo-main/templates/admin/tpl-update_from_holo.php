<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
?>
<form method="post">
    <table class="form-table">
        <tbody>
        <tr>
            <th scope="row">
                <label for="update_product_price">
                    <?php _e('Update product price','wooholo');?>
                </label>
            </th>
            <td>
                <select class="" name="update_product_price">
                    <option value="0" <?php if(isset($_POST['update_product_price'])&&$_POST['update_product_price']=='0') echo 'selected'; else if(!isset($_POST['update_product_price'])&&isset($options['update_product_price'])&&$options['update_product_price']=='0') echo 'selected'?>>
                        <?php _e('OFF','wooholo');?>
                    </option>
                    <option value="1" <?php if(isset($_POST['update_product_price'])&&$_POST['update_product_price']=='1') echo 'selected'; else if(!isset($_POST['update_product_price'])&&isset($options['update_product_price'])&&$options['update_product_price']=='1') echo 'selected'?>>
                        <?php _e('ON','wooholo');?>
                    </option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="update_product_stock">
                    <?php _e('Update product stock','wooholo');?>
                </label>
            </th>
            <td>
                <select class="" name="update_product_stock">
                    <option value="0" <?php if(isset($_POST['update_product_stock'])&&$_POST['update_product_stock']=='0') echo 'selected'; else if(!isset($_POST['update_product_stock'])&&isset($options['update_product_stock'])&&$options['update_product_stock']=='0') echo 'selected'?>>
                        <?php _e('OFF','wooholo');?>
                    </option>
                    <option value="1" <?php if(isset($_POST['update_product_stock'])&&$_POST['update_product_stock']=='1') echo 'selected'; else if(!isset($_POST['update_product_stock'])&&isset($options['update_product_stock'])&&$options['update_product_stock']=='1') echo 'selected'?>>
                        <?php _e('ON','wooholo');?>
                    </option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="update_product_name">
                    <?php _e('Update product name','wooholo');?>
                </label>
            </th>
            <td>
                <select class="" name="update_product_name">
                    <option value="0" <?php if(isset($_POST['update_product_name'])&&$_POST['update_product_name']=='0') echo 'selected'; else if(!isset($_POST['update_product_name'])&&isset($options['update_product_name'])&&$options['update_product_name']=='0') echo 'selected'?>>
                        <?php _e('OFF','wooholo');?>
                    </option>
                    <option value="1" <?php if(isset($_POST['update_product_name'])&&$_POST['update_product_name']=='1') echo 'selected'; else if(!isset($_POST['update_product_name'])&&isset($options['update_product_name'])&&$options['update_product_name']=='1') echo 'selected'?>>
                        <?php _e('ON','wooholo');?>
                    </option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="insert_new_product">
                    <?php _e('Insert new product','wooholo');?>
                </label>
            </th>
            <td>
                <select class="" name="insert_new_product">
                    <option value="0" <?php if(isset($_POST['insert_new_product'])&&$_POST['insert_new_product']=='0') echo 'selected'; else if(!isset($_POST['insert_new_product'])&&isset($options['insert_new_product'])&&$options['insert_new_product']=='0') echo 'selected'?>>
                        <?php _e('OFF','wooholo');?>
                    </option>
                    <option value="1" <?php if(isset($_POST['insert_new_product'])&&$_POST['insert_new_product']=='1') echo 'selected'; else if(!isset($_POST['insert_new_product'])&&isset($options['insert_new_product'])&&$options['insert_new_product']=='1') echo 'selected'?>>
                        <?php _e('ON','wooholo');?>
                    </option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="insert_product_with_zero_inventory">
                    <?php _e('Insert product with zero inventory','wooholo');?>
                </label>
            </th>
            <td>
                <select class="" name="insert_product_with_zero_inventory">
                    <option value="0" <?php if(isset($_POST['insert_product_with_zero_inventory'])&&$_POST['insert_product_with_zero_inventory']=='0') echo 'selected'; else if(!isset($_POST['insert_product_with_zero_inventory'])&&isset($options['insert_product_with_zero_inventory'])&&$options['insert_product_with_zero_inventory']=='0') echo 'selected'?>>
                        <?php _e('OFF','wooholo');?>
                    </option>
                    <option value="1" <?php if(isset($_POST['insert_product_with_zero_inventory'])&&$_POST['insert_product_with_zero_inventory']=='1') echo 'selected'; else if(!isset($_POST['insert_product_with_zero_inventory'])&&isset($options['insert_product_with_zero_inventory'])&&$options['insert_product_with_zero_inventory']=='1') echo 'selected'?>>
                        <?php _e('ON','wooholo');?>
                    </option>
                </select>
            </td>
        </tr>
        </tbody>
    </table>
    <?php

    wp_nonce_field( 'woo_holo_save_update_from_holo_nonce', 'woo_holo_update_from_holo_nonce' );

    submit_button( __('Save Change','wooholo'), 'primary', 'woo_holo_save_update_from_holo', true );
    ?>
</form>
