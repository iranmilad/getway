<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
if(count($options['holo_categories'])==0){
    echo '<div class="alert alert-danger m-10">'.__('import category in general tab.', 'wooholo').'</div>';
    return;
}
$cp=10;
if(isset($_GET['cp'])){
    $cp=$_GET['cp'];
}
function get_child_category_woocommerce($woo_categories,$name_field,$options){
    $html='';
    foreach($woo_categories as $key=>$value){
        $select='';
        $r=$value['tr'];
        $name=$value['name'];
        if (isset($_POST['product_cat'][$name_field])&&in_array($key,$_POST['product_cat'][$name_field])) {
            $select = "selected";
        }
        else if(!isset($_POST['product_cat'][$name_field])&&isset($options['product_cat'][$name_field]) && in_array($key,$options['product_cat'][$name_field]))
        {
            $select = "selected";
        }
        $html .= '<option value="' . $key . '" ' . $select . '>'.$r.$name .'</option>'; //Parent Category
    }
    return $html;
}
if(!isset($_GET['pagination'])){
    $page=0;
}
else{
    $page=$_GET['pagination'];
}
?>
<div class="cp">
    <label><?php _e('Number of views per page','wooholo')?></label>
    <select name="count-pagination">
        <option value="5" <?php if($cp==5) echo 'selected';?>>5</option>
        <option value="10" <?php if($cp==10) echo 'selected';?>>10</option>
        <option value="20" <?php if($cp==20) echo 'selected';?>>20</option>
        <option value="30" <?php if($cp==30) echo 'selected';?>>30</option>
        <option value="40" <?php if($cp==40) echo 'selected';?>>40</option>
        <option value="50" <?php if($cp==50) echo 'selected';?>>50</option>
    </select>
</div>
<form method="post">
    <table class="form-table">
        <tbody>
        <?php
        if(isset($options['holo_categories'])&&!empty($options['holo_categories'])){
            $holo_categories=array_slice($options['holo_categories'],$page*$cp,$cp);
            foreach ($holo_categories as $holo_category){
                ?>
                <tr>
                    <th scope="row">
                        <label for="product_cat_<?php echo $holo_category->m_groupcode; ?>">
                            <?php echo $holo_category->m_groupname; ?>
                        </label>
                    </th>
                    <td class="">
                        <select class="holo-category" name="product_cat[<?php echo $holo_category->m_groupcode; ?>][]" multiple="multiple">
                            <option
                                    value=""
                                <?php
                                if (isset($_POST['product_cat'][$holo_category->m_groupcode])&&in_array('',$_POST['product_cat'][$holo_category->m_groupcode])) {
                                   echo "selected";
                                }
                                else if(isset($options['product_cat'][$holo_category->m_groupcode]) &&
                                    in_array('',$options['product_cat'][$holo_category->m_groupcode])&&
                                    array_count_values($_POST['product_cat'])[""]==count($_POST['product_cat'])
                                )
                                {
                                   echo "selected";
                                }
                                else if (!isset($options['product_cat'][$holo_category->m_groupcode])){
                                    echo "selected";
                                }
                                ?>
                            ><?php _e('not save','wooholo');?></option>
                            <?php echo get_child_category_woocommerce($woo_categories,$holo_category->m_groupcode,$options);?>
                        </select>
                    </td>
                </tr>
                <?php
            }
        }
        ?>
        </tbody>
    </table>
    <?php
    wp_nonce_field( 'woo_holo_save_product_category_nonce', 'woo_holo_product_category_nonce' );
    submit_button( __('Save Change','wooholo'), 'primary', 'woo_holo_save_product_category', true );
    ?>
</form>
<?php
 if(isset($options['holo_categories'])&&count($options['holo_categories'])>$cp){?>
<nav aria-label="...">
    <ul class="pagination pagination-sm">
        <li class="page-item">
            <a class="page-link" href="<?php echo site_url();?>/wp-admin/admin.php?page=woo-holo&tab=product_category&pagination=<?php echo $page-1 ?>&cp=<?php echo $cp; ?>" tabindex="-1"> > </a>
        </li>
        <?php
        if(isset($options['holo_categories'])&&count($options['holo_categories'])>$cp){
            for($i=0;$i<count($options['holo_categories'])/$cp;$i++)  {?>
                <li class="page-item <?php if($page==$i) echo 'active'; ?>" ><a class="page-link" href="<?php echo site_url();?>/wp-admin/admin.php?page=woo-holo&tab=product_category&pagination=<?php echo $i; ?>&cp=<?php echo $cp; ?>"><?php echo $i;?></a></li>
            <?php }}?>
        <li class="page-item">
            <a class="page-link" href="<?php echo site_url();?>/wp-admin/admin.php?page=woo-holo&tab=product_category&pagination=<?php echo $page+1 ?>&cp=<?php echo $cp; ?>"> < </a>
        </li>
    </ul>
</nav>
<?php }?>
