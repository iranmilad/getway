<?php
namespace WOOHolo;
use WOOHolo\admin\Menu;

class Check_Setting
{
    protected $options=[];
    function __construct(){
        $this->options= get_option( 'woo_holo' );
        add_action( "delete_product_cat",  array($this,'woo_holo_delete_category_update_plugin_setting'),10,4 );
        add_action( "woocommerce_update_options_checkout", array($this,'action_woocommerce_update_options_payment_gateways'), 999 );
    }
    // define the woocommerce_update_options_checkout callback
    public function action_woocommerce_update_options_payment_gateways() {
        $gateways = WC()->payment_gateways->payment_gateways();
        $options = $this->options;
        if(!empty( $gateways )) {
            if(!empty(array_keys($options['payment']))){
                foreach(array_keys($options['payment']) as $key){
                $is_found=false;
                foreach( $gateways as $gateway ) {
                    if( $gateway->enabled == 'yes' ) {
                        if($key==$gateway->id){
                            $is_found=true;
                        }
                    }
                }
                if(!$is_found){
                    unset($options['payment'][$key]);
                }
            }
            }
        }
        else{
            $options['payment']=[];
        }
        update_option('woo_holo',$options);
    }
    /**
     * update plugin setting category if delete woocommerce product category
     */
    public function woo_holo_delete_category_update_plugin_setting($term, $tt_id,  $deleted_term, $object_ids){
      
        $categories=$this->options['product_cat'];
        $data=[];
        foreach($categories as $key=>$value){
            $data[$key]=$value;
            if($value==$term){
                $data[$key]='';
            }
        }
        (new Menu())->woo_holo_update_option('product_cat', false ,false,$data);
    }

    /**
     * check setting categories config
     */
    public function request_available_categories(){
        if(!empty(array_count_values($this->options['product_cat']))&&array_count_values($this->options['product_cat'])[""]==count($this->options['product_cat'])||count($this->options['product_cat'])==0){
            return array('message'=>__('Please Insert Category Setting Before Send Request In Product Category Tab.','wooholo'));
        }
        return true;
    }

    /**
     * check setting payment config
     */
    public function request_available_payment(){
        $this->action_woocommerce_update_options_payment_gateways();
        if(empty($this->options['payment'])){
            return array('message'=>__('Please Insert Payment Setting Before Send Request In Headlines.','wooholo'));
        }
        return true;
    }
}