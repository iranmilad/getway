<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );

 if(count($options['holo_categories'])==0){
    echo '<div class="alert alert-danger m-10">'.__('import category in general tab.', 'wooholo').'</div>';
    return;
}
function woo_holo_all_category($options,$name_field)
{
    $html='';
    $parent_cat_arg = array('hide_empty' => false, 'parent' => 0);
    $parent_categories = get_terms('product_cat', $parent_cat_arg);
    foreach ($parent_categories as $category) {
        echo get_child_category_woocommerce($category,$name_field,$options,'');
        $child_arg = array('hide_empty' => false, 'parent' => $category->term_id);
        $child_cat = get_terms('product_cat', $child_arg);
        foreach ($child_cat as $child_term) {
            echo get_child_category_woocommerce($child_term,$name_field,$options,'-');
            $child2_arg = array('hide_empty' => false, 'parent' => $child_term->term_id);
            $child2_cat = get_terms('product_cat', $child2_arg);
            if (!empty($child2_cat)) {
                foreach ($child2_cat as $child2_term) {
                    echo get_child_category_woocommerce($child2_term, $name_field,$options, "--");
                    $child3_arg = array('hide_empty' => false, 'parent' => $child2_term->term_id);
                    $child3_cat = get_terms('product_cat', $child3_arg);
                    if (!empty($child3_cat)) {
                        foreach ($child3_cat as $child3_term) {
                            echo get_child_category_woocommerce($child3_term, $name_field, $options,'---');
                            $child4_arg = array('hide_empty' => false, 'parent' => $child3_term->term_id);
                            $child4_cat = get_terms('product_cat', $child4_arg);
                            if (!empty($child4_cat)) {
                                foreach ($child4_cat as $child4_term) {
                                    echo get_child_category_woocommerce($child4_term, $name_field, $options,'----');
                                    $child5_arg = array('hide_empty' => false, 'parent' => $child4_term->term_id);
                                    $child5_cat = get_terms('product_cat', $child5_arg);
                                    if (!empty($child5_cat)) {
                                        foreach ($child5_cat as $child5_term) {
                                            echo get_child_category_woocommerce($child5_term, $name_field,$options, '-----');
                                            $child6_arg = array('hide_empty' => false, 'parent' => $child5_term->term_id);
                                            $child6_cat = get_terms('product_cat', $child6_arg);
                                            if (!empty($child6_cat)) {
                                                foreach ($child6_cat as $child6_term) {
                                                    echo get_child_category_woocommerce($child6_term, $name_field, $options,'------');
                                                    $child7_arg = array('hide_empty' => false, 'parent' => $child6_term->term_id);
                                                    $child7_cat = get_terms('product_cat', $child7_arg);
                                                    if (!empty($child7_cat)) {
                                                        foreach ($child7_cat as $child7_term) {
                                                            echo get_child_category_woocommerce($child7_term, $name_field, $options,'-------');
                                                            $child8_arg = array('hide_empty' => false, 'parent' => $child7_term->term_id);
                                                            $child8_cat = get_terms('product_cat', $child8_arg);
                                                            if (!empty($child8_cat)) {
                                                                foreach ($child8_cat as $child8_term) {
                                                                    echo get_child_category_woocommerce($child8_term, $name_field, $options,'--------');
                                                                    $child9_arg = array('hide_empty' => false, 'parent' => $child8_term->term_id);
                                                                    $child9_cat = get_terms('product_cat', $child9_arg);
                                                                    if (!empty($child9_cat)) {
                                                                        foreach ($child9_cat as $child9_term) {
                                                                            echo get_child_category_woocommerce($child9_term, $name_field, $options,'---------');
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return $html;
}
 function get_child_category_woocommerce($child_term,$name_field,$options,$r=''){
    $html='';
     $select='';
     if (isset($_POST['product_cat'][$name_field])) {
         if ($_POST['product_cat'][$name_field] == $child_term->term_id) {
             $select = "selected";
         }
     }
     else if(isset($options['product_cat'][$name_field]) && $options['product_cat'][$name_field] == $child_term->term_id)
     {
         $select = "selected";
     }
     $html .= '<option value="' . $child_term->term_id . '" ' . $select . '>'.$r.$child_term->name .'</option>'; //Parent Category
    return $html;
 }
?>
<form method="post">
    <table class="form-table">
        <tbody>
        <?php
        if(isset($options['holo_categories'])&&!empty($options['holo_categories'])){
            foreach ($options['holo_categories'] as $holo_category){
                ?>
                <tr>
                    <th scope="row">
                        <label for="product_cat_<?php echo $holo_category->m_groupcode; ?>">
                            <?php echo $holo_category->m_groupname; ?>
                        </label>
                    </th>
                    <td>
                        <select class="" name="product_cat[<?php echo $holo_category->m_groupcode; ?>]">
                            <option value=""><?php _e("not save",'wooholo');?></option>
                            <?php echo woo_holo_all_category($options,$holo_category->m_groupcode);?>
                        </select>
                    </td>
                </tr>
            <?php }
        }
        ?>
        </tbody>
    </table>
    <?php

    wp_nonce_field( 'woo_holo_save_product_category_nonce', 'woo_holo_product_category_nonce' );

    submit_button( __('Save Change','wooholo'), 'primary', 'woo_holo_save_product_category', true );
    ?>
</form>
