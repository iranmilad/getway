<?php


namespace WOOHolo;


class Enqueue
{
    function __construct()
    {
        add_action( 'admin_enqueue_scripts', array($this, 'woo_holo_admin_add_enqueue') );

    }
    /*
     * add style.css to admin wordpress
     */
    function woo_holo_admin_add_enqueue($hook){
        wp_enqueue_style('holo-style',WOOHOLO_URI.'assets/css/style.css');
       
        if ( 'toplevel_page_woo-holo' != $hook ) {
            return;
        }
        wp_enqueue_style('bootstrap','https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css');
        wp_enqueue_script('bootstrap','https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js');
        wp_enqueue_script('jquery3.2.1','https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js');
        wp_enqueue_style('dataTables','https://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css');
        wp_enqueue_script('dataTables','https://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js');
        wp_enqueue_script('wooholo',WOOHOLO_URI.'assets/js/wooholo.js');
         wp_localize_script(
		'wooholo',
		'wooholo_ajax_obj',
    		array(
    			'ajaxurl' => admin_url( 'admin-ajax.php' ),
    			'WOOHOLOSERVER_URL' => WOOHOLOSERVER_URL,
    			'nonce' => wp_create_nonce('ajax-nonce')
    		)
        );
    }
}