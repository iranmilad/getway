<?php

/*
 * The plugin bootstrap file
 *
 * Plugin Name:       افزونه نیلا - اتصال دهنده فروشگاه اینترنتی و نرم افزار حسابداری هلو
 * Plugin URI:        https://www.holooideh.com/product/%d8%a7%d9%81%d8%b2%d9%88%d9%86%d9%87_%d8%a7%d8%b1%d8%aa%d8%a8%d8%a7%d8%b7_%d9%88%d9%88%da%a9%d8%a7%d9%85%d8%b1%d8%b3_%d9%88%d8%a8%e2%80%8c%d8%b3%d8%b1%d9%88%db%8c%d8%b3_%d9%87%d9%84%d9%88/
 * Description:       انتقال کالا از هلو به سایت، به روز رسانی موجودی و قیمت، ثبت طرف حساب و فاکتورآنلاین  در نرم‌افزار حساب‌داری هلو
 * Version:           2.02.02
 * Author:            ایده نگار ماهان
 * Author URI:        https://www.holooideh.com
 * License:           GPL-2.0+
 * License URI:       n/a
 * Text Domain:       wooholo
 * Domain Path:       /languages
 *
 */

if( ! defined('ABSPATH') ) {
    return;
}
if(file_exists(dirname(__FILE__).'/vendor/autoload.php')){
    require_once dirname(__FILE__).'/vendor/autoload.php';
}
if(file_exists(dirname(__FILE__).'/Update_Plugin.php')){
    require_once dirname(__FILE__).'/Update_Plugin.php';
}
new Update_Plugin(
    'https://laravel.clawar-services.org/update/wooholo-update.json',
    plugin_basename(__FILE__),
    __FILE__, //Full path to the main plugin file or functions.php.
    'wc-holo-main'
);
/*
 * textdomain
 *
 */
if( ! function_exists('woo_holo_load_textdomain')) {
    function woo_holo_load_textdomain() {
        load_plugin_textdomain('wooholo', false, basename( dirname( __FILE__ ) ) . '/languages');
    }
    add_action('init', 'woo_holo_load_textdomain');
}
/*
 * const
 *
 */
define('WOOHOLO_PLUGIN', __FILE__ );
define('WOOHOLO_PATH', wp_normalize_path( plugin_dir_path( __FILE__ ) . DIRECTORY_SEPARATOR ));
define('WOOHOLO_URI', plugin_dir_url( __FILE__ ));
define('WOOHOLO_VERSION', '1.0.0');

/*
 * const server
 *
 */
define('WOOHOLOSERVER_URL','https://www.laravel.clawar-services.org');
define('WOOHOLOSERVER_VALIDATE',['wcGetExcelProducts','wcAddAllHolooProductsCategory','updateAllProductFromHolooToWC','getProductConflict','wcSingleProductUpdate']);
define('WOOHOLOSERVER_GETKEY','#');
register_activation_hook(__FILE__, array(new WOOHolo\admin\Activate(), "active"));

new WOOHolo\admin\Menu();
new WOOHolo\Check_Setting();
new WOOHolo\woocommerce\Product();
new WOOHolo\woocommerce\Order();
new WOOHolo\Enqueue();
new WOOHolo\Api();
new WOOHolo\woocommerce\Rest_api();
new WOOHolo\admin\Action();
new WOOHolo\admin\Ajax;
