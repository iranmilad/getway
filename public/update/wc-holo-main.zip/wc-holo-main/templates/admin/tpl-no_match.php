<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
function woo_holo_all_category()
{
    $html='';
    $parent_cat_arg = array('hide_empty' => false, 'parent' => 0);
    $parent_categories = get_terms('product_cat', $parent_cat_arg);
    foreach ($parent_categories as $category) {
        $html .='<option value="' . $category->term_id . '" ' . $select . '>' . $category->name . '</option>'; //Parent Category
        $child_arg = array('hide_empty' => false, 'parent' => $category->term_id);
        $child_cat = get_terms('product_cat', $child_arg);
        foreach ($child_cat as $child_term) {
            $html .= '<option value="' . $child_term->term_id . '" ' . $select_1 . '>-' . $child_term->name . '</option>'; //Parent Category
            $child2_arg = array('hide_empty' => false, 'parent' => $child_term->term_id);
            $child2_cat = get_terms('product_cat', $child2_arg);
            foreach ($child2_cat as $child2_term) {
                $html .= '<option value="' . $child2_term->term_id . '" ' . $select_2 . '>--' . $child2_term->name . '</option>'; //Parent Category
            }
        }
    }
    return $html;
}
?>
    <form class="box-search">
        <div class="form-group">
            <label><?php _e('Category','wooholo');?></label>
             <select name="category">
                 <option value=""><?php _e('All','wooholo');?></option>
            <?php
             echo woo_holo_all_category();
            ?>
        </select>
        </div>
       <div class="form-group">
            <label><?php _e('Number of views','wooholo');?></label>
            <select name="per_page">
               <option value="10">10</option>
               <option value="10">20</option>
               <option value="10">30</option>
               <option value="10">50</option>
               <option value="10">100</option>
               <option value="10">150</option>
               <option value="10">200</option>
               <option value=''><?php _e('All','wooholo')?></option>
            </select>
       </div>
        <button class="btn btn-success" id="search-match"><?php _e('search','wooholo') ?></button>
    </form>
<div class="match">
    <table id="woholoTabel" class="table table-striped table-bordered form-table" style="width:100%">
        <thead>
        <tr>
            <th><?php _e('Product id','wooholo');?></th>
            <th><?php _e('Product title','wooholo');?></th>
            <th><?php _e('Product stock','wooholo');?></th>
            <th><?php _e('Product price','wooholo');?></th>
            <th><?php _e('holo sku','wooholo');?></th>
            <th><?php _e('Message','wooholo');?></th>
            <th><?php _e('Action','wooholo');?></th>
        </tr>
        </thead>
    </table>
    <div id="ploading"><?php _e('loading....','wooholo');?></div>
</div>

