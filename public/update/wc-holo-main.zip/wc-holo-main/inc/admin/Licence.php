<?php
namespace WOOHolo\Admin;
use WOOHolo\admin\Action;
use mysql_xdevapi\Exception;
use WOOHolo\admin\GetWay;
if(!class_exists('Licence')){
    class Licence
    {
        public function __construct()
        {

        }
        public function check_licence_key($licence)
        {
            try {
                $response=(new GetWay)->login($licence,$status='firstLogin');
                if(isset($response->responseCode)&&$response->responseCode=200&&isset($response->response->token)) {
                    if($response->response->server_url){
                        (new Menu())->woo_holo_update_option( 'server_url', false ,false,$response->response->server_url);
                        $response=(new GetWay)->login($licence,$status='firstLogin');
                    }
                    (new Action())->woo_holo_log('login successful to holo server and get token: '.$response->message);
                    return $response;
                }
                elseif (isset($response->responseCode)&&$response->responseCode!=200){
                    (new Action())->woo_holo_log('get error '.$response->responseCode.' from login getway');
                    return $response;
                }
                else{
                    (new Action())->woo_holo_log('error get login response: '.json_encode($response));
                    return __('getWay message is: '.$response->message,'wooholo');
                }
            }
            catch (Exception $exception) {
                (new Action())->woo_holo_log('can\'t login to holo server "There is no connection from your host!"');
                return __('There is no connection from your host!','wooholo');
            }
        }
    }
}