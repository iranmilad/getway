<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
function woo_holo_all_shipping($shippings,$options)
{
    $html='';
    foreach ($shippings as $shipping) {
        $select='';
        if (isset($_POST['product_shipping']) ) {
            if ($_POST['product_shipping'] ==  $shipping->sarfasl_Code){
                $select = "selected";
            }
        }
        else if(isset($options['product_shipping']) && $options['product_shipping'] == $shipping->sarfasl_Code){
            $select = "selected";
        }
        $html .='<option value="' . $shipping->sarfasl_Code . '" ' . $select . '>' .$shipping->sarfasl_Name . '</option>'; //Parent Category
    }
    return $html;
}?>
<form method="post">
    <table class="form-table">
        <tbody>
        <tr>
            <th scope="row">
                <label>
                    <?php _e('Product code shipping cost','wooholo')?>
                </label>
            </th>
            <td>
                <select name="product_shipping">
                    <?php echo woo_holo_all_shipping($shippings,$options);?>
                </select>
            </td>
        </tr>

        </tbody>
    </table>
    <?php
    wp_nonce_field( 'woo_holo_save_connection_nonce', 'woo_holo_connection_nonce' );

    submit_button(__('Save Change','wooholo'), 'primary', 'woo_holo_save_connection', true );
    ?>
</form>
