<?php
namespace WOOHolo\admin;
use WOOHolo\admin\GetWay;
use WOOHolo\admin\Action;
if(!class_exists('Menu')){
    class Menu
    {
        protected $woo_holo_options;
        public function __construct() {
            $this->woo_holo_options= get_option('woo_holo');
            /*
             * add menu plugin to admin panel wordpress
             */
            add_action( 'admin_menu', array($this,'woo_holo_plugin_menu'),10);
        }
        public function woo_holo_plugin_menu() {
            $hook= add_menu_page(
                __( 'nila', 'wooholo' ),
                __( 'nila', 'wooholo' ),
                'manage_options',
                'woo-holo',
                array($this,'woo_holo_settings'),
                WOOHOLO_URI.'assets/images/Holoo.png',
                6
            );
        }
        public function woo_holo_settings(){
            ?>
            <div class="wooholo-warp wrap">
                <?php
                include  WOOHOLO_PATH. 'templates/admin/tpl-banner.php';
                ?>
                <h2>
                    <?php _e('Setting nila','wooholo');?>
                </h2>
                <nav class="nav-tab-wrapper">
                    <?php
                    foreach ( $this->woo_holo_allowed_tab() as $tab_key => $tab_label ) {
                        echo '<a href="' . esc_url( add_query_arg( array( 'tab' => $tab_key ) ) ) . '" class="nav-tab ' .$this->woo_holo_get_active_class( $tab_key ) . ' '.$tab_key.'">' . $tab_label . '</a>';
                    }
                    ?>
                </nav>
                <?php $this->woo_holo_get_tab_content(); ?>
            </div>
            <?php
        }
        /*
         * add submenu to setting page plugin
         */
        public function woo_holo_allowed_tab() {
            if(isset($this->woo_holo_options['licence_key'])&&isset($this->woo_holo_options['licence_status'])&&$this->woo_holo_options['licence_status']=='active') {
                return array(
                    'general' => __('general Setting', 'wooholo'),
                    'product_category' => __('Product Category', 'wooholo'),
                    'headlines' => __('Headlines', 'wooholo'),
                    'connection' => __('Connection Configuration', 'wooholo'),
                    'main' => __('Main Setting', 'wooholo'),
                    'update_from_holo' => __('Update from holo', 'wooholo'),
                    'no_match' => __('No Match', 'wooholo'),
                    'licence' => __('licence', 'wooholo'),
                );
            }
            else{
                return array(
                    'licence' => __('licence', 'wooholo'),
                );
            }
        }
        /*
        * add class active to active tab
        */
        public function woo_holo_get_active_class( $tab ) {
            return $this->woo_holo_get_active_tab() == $tab ? 'nav-tab-active' : null;
        }
        /*
        * include tab content in setting page
        */
        public function woo_holo_get_tab_content() {
            $file = WOOHOLO_PATH . 'templates/admin/tpl-' . $this->woo_holo_get_active_tab() . '.php';
            if ( is_file( $file ) && file_exists( $file ) ) {
                $options=$this->woo_holo_options;
                if($this->woo_holo_get_active_tab()=='headlines'){
                    $accounts=[];
                    $data=(new GetWay)->connection('GetAllAccount');
                    if(isset($data->responseCode)&&$data->responseCode==200){
                        $accounts = $data->response;
                    }
                    else if(isset($data->responseCode)&&$data->responseCode!=200){
                        (new Action())->woo_holo_log('Error in root GetAllAccount: '.$data->message);
                    }
                    else{
                        (new Action())->woo_holo_log('Error in root GetAllAccount: '.json_encode($data));
                    }
                }
                if($this->woo_holo_get_active_tab()=='connection'){
                    $shippings=[];
                    $CustomerAccount=[];
                   /* $data=(new GetWay)->connection('GetShippingAccount');
                    if(isset($data->responseCode)&&$data->responseCode==200){
                        $shippings = $data->response;
                    }*/
                    $response=(new GetWay)->connection('GetAllCustomerAccount');
                    if(isset($response->responseCode)&&$response->responseCode==200){
                        $CustomerAccounts = $response->response;
                    }
                    else if(isset($response->responseCode)&&$response->responseCode!=200){
                        (new Action())->woo_holo_log('Error in root GetAllCustomerAccount: '.$response->message);
                    }
                    else{
                        (new Action())->woo_holo_log('Error in root GetAllCustomerAccount: '.json_encode($response));
                    }
                }
                do_action('before_holo_'.$this->woo_holo_get_active_tab().'_tab');
                include $file;
                do_action('after_holo_'.$this->woo_holo_get_active_tab().'_tab');
                if($this->woo_holo_get_active_tab()!='no_match'){
                    $save_function = 'woo_holo_save_' . str_replace( '-', '_', $this->woo_holo_get_active_tab() ) . '_options';
                    call_user_func(array(__NAMESPACE__ .'\Menu', $save_function));
                }
            }
        }
        /*
       * find active tab in all submenu tabs
       */
        public function woo_holo_get_active_tab() {
            $tab = array_keys( $this->woo_holo_allowed_tab())[0];

            if ( isset( $_GET['tab'] ) && in_array( $_GET['tab'], array_keys($this->woo_holo_allowed_tab() ) ) ) {
                $tab = $_GET['tab'];
            }

            return $tab;
        }
        /*
       * save data for licence tab
       */
        public function woo_holo_save_licence_options() {
            if ( isset( $_POST['woo_holo_save_licence'] ) ) {
                if ( ! isset( $_POST['woo_holo_licence_nonce'] ) || ! wp_verify_nonce( $_POST['woo_holo_licence_nonce'], 'woo_holo_save_licence_nonce' ) ) {
                    exit( __('Sorry, your nonce did not verify!','wooholo') );
                } else {
                    $this->set_default_options();
                    $login = (new \WOOHolo\admin\Licence())->check_licence_key($_POST['licence_key']);
                    if(isset($login)){
                        if(isset($login->responseCode)&&$login->responseCode=200&&isset($login->response->token)){
                            $this->woo_holo_update_option( 'licence_status', false ,false,'active');
                            $this->woo_holo_update_option( 'holo_status', false ,false,'ok');
                            $this->woo_holo_update_option( 'licence_key', false );
                            /// send option to GetWay
                            $result=(new GetWay)->connection('updateConfig');
                            if($result->responseCode==200){
                                (new Action())->woo_holo_log('send plugin options to getWay Successful');
                            }
                            $api_key=$this->update_api_key('','read_write');
                            if(!isset($api_key['consumer_key'])&&!isset($api_key['consumer_secret'])){
                                (new Action())->woo_holo_log('Error! can\'t create new consumer_key & consumer_secret /n plugin options: '.$this->woo_holo_options);
                                _e('Error! can\'t create new consumer_key & consumer_secret','woohole');
                                return;
                            }
                            $send_key=(new GetWay)->connection('updateUser',array('consumerKey'=>$api_key['consumer_key'],'consumerSecret'=>$api_key['consumer_secret']));
                            if($send_key->responseCode==200){
                                $this->set_default_category_headlins_options();
                                (new Action())->woo_holo_log('consumer_key & consumer_secret success send to GetWay::responseCode: '.$send_key->responseCode.'::responsMessage: '.$send_key->message);
                                echo $send_key->message;
                                wp_redirect($_SERVER['HTTP_REFERER']);
                            }
                            else{
                                echo $send_key->message;
                                (new Action())->woo_holo_log('Error! consumer_key & consumer_secret send to GetWay::responseCode: '.$send_key->responseCode.'::responsMessage: '.$send_key->message);
                            }
                        }
                        else if(isset($login->responseCode)&&$login->responseCode!=200){
                            (new Action())->woo_holo_log('Error in root login: '.$login->message);
                        }
                        else{
                            $this->woo_holo_update_option( 'licence_status', false ,false,'NOK');
                            $this->woo_holo_update_option( 'holo_status', false ,false,'NOK');
                            $this->woo_holo_update_option( 'licence_key', false );
                            (new Action())->woo_holo_log('Error! Login to getway not success::responseCode: '.json_encode($login));
                            /// send option to GetWay
                            $result=(new GetWay)->connection('updateConfig');
                            if($result->responseCode==200){
                                (new Action())->woo_holo_log('send plugin options to getWay Successful');
                            }
                            echo $login->message;
                        }
                    }
                    else{
                        echo 'Eroor';
                        (new Action())->woo_holo_log('Error! Login to getway not success');
                    }

                }
            }
        }
        /*
      * save data for general tab
      */
        public function woo_holo_save_general_options() {
            if ( isset( $_POST['woo_holo_save_general'] ) ) {
                if ( ! isset( $_POST['woo_holo_general_nonce'] ) || ! wp_verify_nonce( $_POST['woo_holo_general_nonce'], 'woo_holo_save_general_nonce' ) ) {
                    exit( __('Sorry, your nonce did not verify!','wooholo') );
                } else {
                    _e('Updated Successful','wooholo');
                }
            }
        }
        /*
      * save data for connection tab
      */
        public function woo_holo_save_connection_options() {
            if ( isset( $_POST['woo_holo_save_connection'] ) ) {
                if ( ! isset( $_POST['woo_holo_connection_nonce'] ) || ! wp_verify_nonce( $_POST['woo_holo_connection_nonce'], 'woo_holo_save_connection_nonce' ) ) {
                    exit( __('Sorry, your nonce did not verify!','wooholo') );
                } else {
                    $this->woo_holo_update_option( 'product_shipping', false );
                    $this->woo_holo_update_option( 'customer_account', false );
                    (new Action())->woo_holo_log('Updated Successful connection options');
                    /// send option to GetWay
                    $result=(new GetWay)->connection('updateConfig');
                    if($result->responseCode==200){
                        (new Action())->woo_holo_log('send plugin options to getWay Successful');
                    }
                    _e('Updated Successful','wooholo');
                }
            }
        }
        /*
      * save data for headlines tab
      */
        public function woo_holo_save_headlines_options() {
            if ( isset( $_POST['woo_holo_save_headlines'] ) ) {
                if ( ! isset( $_POST['woo_holo_headlines_nonce'] ) || ! wp_verify_nonce( $_POST['woo_holo_headlines_nonce'], 'woo_holo_save_headlines_nonce' ) ) {
                    exit( __('Sorry, your nonce did not verify!','wooholo') );
                } else {
                    $this->woo_holo_update_option( 'payment', false );
                    $this->woo_holo_update_option( 'payment', false );
                    $this->woo_holo_update_option( 'payment', false );
                    (new Action())->woo_holo_log('Updated Successful headlines option');
                    /// send option to GetWay
                    $result=(new GetWay)->connection('updateConfig');
                    if($result->responseCode==200){
                        (new Action())->woo_holo_log('send plugin options to getWay Successful');
                    }
                    _e('Updated Successful','wooholo');
                }
            }
        }
        /*
      * save data for product categories tab
      */
        public function woo_holo_save_product_category_options() {
            if ( isset( $_POST['woo_holo_save_product_category'] ) ) {
                if ( ! isset( $_POST['woo_holo_product_category_nonce'] ) || ! wp_verify_nonce( $_POST['woo_holo_product_category_nonce'], 'woo_holo_save_product_category_nonce' ) ) {
                    exit( __('Sorry, your nonce did not verify!','wooholo') );
                } else {
                    $this->woo_holo_update_option( "product_cat", false );
                    (new Action())->woo_holo_log('Updated Successful product_category option');
                    (new Action())->woo_holo_log($this->woo_holo_options);
                    /// send option to GetWay
                    $result=(new GetWay)->connection('updateConfig');
                    if($result->responseCode==200){
                        (new Action())->woo_holo_log('send plugin options to getWay Successful');
                    }
                    _e('Updated Successful','wooholo');
                }
            }
        }
        /*
      * save data for main tab
      */
        public function woo_holo_save_main_options() {
            if ( isset( $_POST['woo_holo_save_main'] ) ) {
                if ( ! isset( $_POST['woo_holo_main_nonce'] ) || ! wp_verify_nonce( $_POST['woo_holo_main_nonce'], 'woo_holo_save_main_nonce' ) ) {
                    exit( __('Sorry, your nonce did not verify!','wooholo') );
                } else {
                    $this->woo_holo_update_option( 'invoice_items_no_holo_code', false );
                    $this->woo_holo_update_option( 'status_place_payment', false );
                    $this->woo_holo_update_option( 'special_price_field', false );
                    $this->woo_holo_update_option( 'sales_price_field', false );
                    $this->woo_holo_update_option( 'wholesale_price_field', false );
                    $this->woo_holo_update_option( 'product_stock_field', false );
                    $this->woo_holo_update_option( 'save_sale_invoice', false );
                    $this->woo_holo_update_option( 'save_pre_sale_invoice', false );
                    (new Action())->woo_holo_log('Updated Successful main option');
                    /// send option to GetWay
                    $result=(new GetWay)->connection('updateConfig');
                    if($result->responseCode==200){
                        (new Action())->woo_holo_log('send plugin options to getWay Successful');
                    }
                    _e('Updated Successful','wooholo');
                }
            }
        }
        /*
         * save data for update from holo tab
        */
        public function woo_holo_save_update_from_holo_options() {
            if ( isset( $_POST['woo_holo_save_update_from_holo'] ) ) {
                if ( ! isset( $_POST['woo_holo_update_from_holo_nonce'] ) || ! wp_verify_nonce( $_POST['woo_holo_update_from_holo_nonce'], 'woo_holo_save_update_from_holo_nonce' ) ) {
                    exit( __('Sorry, your nonce did not verify!','wooholo') );
                } else {
                    $this->woo_holo_update_option( 'update_product_price', false );
                    $this->woo_holo_update_option( 'update_product_stock', false );
                    $this->woo_holo_update_option( 'update_product_name', false );
                    $this->woo_holo_update_option( 'insert_new_product', false );
                    $this->woo_holo_update_option( 'insert_product_with_zero_inventory', false );
                    (new Action())->woo_holo_log('Updated Successful update_from_holo option');
                    /// send option to GetWay
                    $result=(new GetWay)->connection('updateConfig');
                    if($result->responseCode==200){
                        (new Action())->woo_holo_log('send plugin options to getWay Successful');
                    }
                    _e('Updated Successful','wooholo');
                }
            }
        }
        /*
         * update options holo
        */
        public function woo_holo_update_option( $key,$sanitize = true, $html = false, $value='' ) {
            $options = get_option( 'woo_holo' );
            if ( isset( $_POST[ $key ] )&& $_POST[ $key ]!='' ) {
                if ( $sanitize ) {
                    $options[ $key ] = sanitize_text_field( $_POST[ $key ] );
                } elseif ( $html ) {
                    $options[ $key ] = stripslashes( wp_filter_post_kses( addslashes( $_POST[ $key ] ) ) );
                } else {
                    $options[ $key ] = $_POST[ $key ];
                }
            }
            else if ($value!=''){
                $options[ $key ] = $value;
            }
            else {
                if ( is_array( $options ) && array_key_exists( $key, $options ) ) {
                    unset( $options[ $key ] );
                }
            }
            update_option( 'woo_holo', $options );
            $this->woo_holo_options= get_option('woo_holo');
        }
        /*
         * create api key woocommerce
        */
        public static function update_api_key($description,$permissions,$key_id=0) {
            ob_start();
            global $wpdb;
            if ( ! current_user_can( 'manage_woocommerce' ) ) {
                wp_die( -1 );
            }
            $response = array();
            try {
                $key_id      = isset( $key_id) ? absint( $key_id ) : 0;
                $description = sanitize_text_field( wp_unslash( $description ) );
                $permissions = ( in_array( wp_unslash( $permissions ), array( 'read', 'write', 'read_write' ), true ) ) ? sanitize_text_field( wp_unslash( $permissions ) ) : 'read';
                $user_id     = absint( get_current_user_id() );
                // Check if current user can edit other users.
                if ( $user_id && ! current_user_can( 'edit_user', $user_id ) ) {
                    if ( get_current_user_id() !== $user_id ) {
                        throw new Exception( __( 'You do not have permission to assign API Keys to the selected user.', 'woocommerce' ) );
                    }
                }
                if ( 0 < $key_id ) {
                    $data = array(
                        'user_id'     => $user_id,
                        'description' => $description,
                        'permissions' => $permissions,
                    );

                    $wpdb->update(
                        $wpdb->prefix . 'woocommerce_api_keys',
                        $data,
                        array( 'key_id' => $key_id ),
                        array(
                            '%d',
                            '%s',
                            '%s',
                        ),
                        array( '%d' )
                    );

                    $response                    = $data;
                    $response['consumer_key']    = '';
                    $response['consumer_secret'] = '';
                    $response['message']         = __( 'API Key updated successfully.', 'woocommerce' );
                } else {
                    $consumer_key    = 'ck_' . wc_rand_hash();
                    $consumer_secret = 'cs_' . wc_rand_hash();

                    $data = array(
                        'user_id'         => $user_id,
                        'description'     => $description,
                        'permissions'     => $permissions,
                        'consumer_key'    => wc_api_hash( $consumer_key ),
                        'consumer_secret' => $consumer_secret,
                        'truncated_key'   => substr( $consumer_key, -7 ),
                    );

                    $wpdb->insert(
                        $wpdb->prefix . 'woocommerce_api_keys',
                        $data,
                        array(
                            '%d',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                        )
                    );

                    $key_id                      = $wpdb->insert_id;
                    $response                    = $data;
                    $response['consumer_key']    = $consumer_key;
                    $response['consumer_secret'] = $consumer_secret;
                    $response['message']         = __( 'API Key generated successfully. Make sure to copy your new keys now as the secret key will be hidden once you leave this page.', 'woocommerce' );
                }
            } catch ( Exception $e ) {
                wp_send_json_error( array( 'message' => $e->getMessage() ) );
            }

            // wp_send_json_success must be outside the try block not to break phpunit tests.
            return  $response ;
        }
        /*
        * update default options holo from json file
       */
        public function set_default_options(){
            $options=file_get_contents(WOOHOLO_PATH.'/templates/admin/default.json');
            update_option( 'woo_holo',(array)json_decode($options) );
            $this->woo_holo_options= get_option('woo_holo');
            (new Action())->woo_holo_log('save default plugin option');

        }
        public function set_default_category_headlins_options(){
            $categories_body=(new GetWay)->connection('getProductCategory');
            if(isset($categories_body->responseCode)&&$categories_body->responseCode==200){
                $holo_categories=$categories_body->response->result;
                (new Action())->woo_holo_log('Import Successful holo categories option');
                $this->woo_holo_update_option('holo_categories',false,false,$holo_categories);
                $options=get_option('woo_holo');
                foreach($holo_categories as $holo_category){
                    $options['product_cat'][$holo_category->m_groupcode]='';
                }
                update_option( 'woo_holo',$options);
            }
            else if(isset($categories_body->responseCode)&&$categories_body->responseCode!=200){
                (new Action())->woo_holo_log('Error in root getProductCategory: '.$categories_body->message);
            }
            else{
                (new Action())->woo_holo_log('Error in root getProductCategory: '.json_encode($categories_body));
            }
            $accounts=[];
            $options=get_option('woo_holo');
            $data=(new GetWay)->connection('GetAllAccount');
            if(isset($data->responseCode)&&$data->responseCode==200) {
                $accounts = $data->response;
                $gateways = WC()->payment_gateways->get_available_payment_gateways();
                if (!empty($gateways)) {
                    foreach ($gateways as $gateway) {
                        if ($gateway->enabled == 'yes') {
                            foreach ($accounts as $account) {
                            $options['payment'][$gateway->id]['number'] = ((array)$accounts)[0]->sarfasl_Code;
                            $options['payment'][$gateway->id]['fee'] = '';
                            $options['payment'][$gateway->id]['vat'] = 0;
                            }
                        }
                    }
                 (new Action())->woo_holo_log('Import All Account holo payment option');
                }
            }
            else if(isset($data->responseCode)&&$data->responseCode!=200){
                (new Action())->woo_holo_log('Error in root GetAllAccount: '.$data->message);
            }
            else{
                (new Action())->woo_holo_log('Error in root GetAllAccount: '.json_encode($data));
            }
            update_option( 'woo_holo',$options);
            $this->woo_holo_options= get_option('woo_holo');
            return true;

        }
    }
}
