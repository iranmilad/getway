<?php
namespace WOOHolo\woocommerce;

class Rest_api
{
    function __construct(){
        add_filter( "woocommerce_rest_product_object_query", array($this,'woo_holo_filter_woocommerce_rest'), 10, 2 );
        add_filter( 'woocommerce_rest_batch_items_limit', array($this,'woo_holo_rest_batch_items_limit'),99,1 );
        add_filter('rest_product_collection_params', array($this,'woo_holo_maximum_api_filter'), 10, 1 );
    }
    function woo_holo_maximum_api_filter($query_params) {
        $query_params['per_page']['maximum'] = 100000;
        $query_params['per_page']['default'] = 10000;
        return $query_params;
    }
    function woo_holo_rest_batch_items_limit( $limit ) {
        $limit = 100000;
        return $limit;
    }
    function woo_holo_filter_woocommerce_rest( $args, $request ) {
        $params = $request->get_query_params();
        if(isset($params['meta'])&&isset( $params['value'])){
            $args['meta_query'] = array(
                array(
                    'key'     => $params['meta'],
                    'value'   => $params['value'],
                    'compare' => 'IN',
                ),
            );
        }
        else if(isset($params['meta'])){
            $args['meta_query'] = array(
                array(
                    'key'     => $params['meta'],
                    'value'   => '',
                    'compare' => '!=',
                ),
            );
        }
        return $args;
    }
}