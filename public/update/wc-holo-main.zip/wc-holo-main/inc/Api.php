<?php
namespace WOOHolo;
use PHPMailer\PHPMailer\Exception;
use WOOHolo\admin\Action;

if(!class_exists('Api')){
    class Api extends \WP_REST_Controller
    {
        private $api_namespace;
        private $base;
        private $api_version;
        private $required_capability;

        public function __construct()
        {
            $this->api_namespace = 'wooholo/v';
            $this->base = 'data';
            $this->api_version = '1';
            /*
             * create rest api for post holo options
             */
            add_action( 'rest_api_init', array( $this, 'register_routes' ) );

            add_filter( 'http_request_timeout',  array( $this, 'woo_hohlo_extend_http_request_timeout'));
        }
        function woo_hohlo_extend_http_request_timeout( $timeout ) {
            return 36000; // seconds
        }
        function register_routes(){
            $namespace = $this->api_namespace . $this->api_version;
            register_rest_route( $namespace, '/' . $this->base,
                array(
                    array(
                        'methods' => \WP_REST_Server::CREATABLE,
                        'callback'            => array( $this, 'get_options' ),
                        'permission_callback' => array( $this, 'create_item_permissions_check' ),
                        'args'                => $this->get_endpoint_args_for_item_schema( true )
                    ),
                )
            );
            register_rest_route( $namespace, '/' . $this->base,
                array(
                    array(
                        'methods' => \WP_REST_Server::READABLE,
                        'callback'            => array( $this, 'test_curl' ),
                        'permission_callback' => array( $this, 'test_curl_permissions_check' ),
                        'args'                => $this->get_endpoint_args_for_item_schema( true )
                    ),
                )
            );
        }
        public function test_curl_permissions_check(){
            return true;
        }
        public function create_item_permissions_check( $request ) {
            global $wpdb;
            $consumer_key=wc_api_hash($request->get_header('consumer_key'));
            $consumer_secret=$request->get_header('consumer_secret');
            $woocommerce_key=$wpdb->get_results( "SELECT * FROM {$wpdb->prefix}woocommerce_api_keys WHERE consumer_key = '$consumer_key' AND consumer_secret = '$consumer_secret'" );
            if($woocommerce_key){
                (new Action())->woo_holo_log('Success! valid consumer_key && consumer_secrete in api get plugin options');
                return true;
            }
            (new Action())->woo_holo_log('Error! Invalid consumer_key && consumer_secrete in api get plugin options');
        }

        public function get_options($request){
            $options = get_option('woo_holo');
            unset($options['holo_token']);
            unset($options['holo_status']);
            unset($options['holo_categories']);
            $options=apply_filters('rest_api_holo_options',$options);
            $response = new \WP_REST_Response();
            $response->set_data($options);
            $response->set_status(200);
            return $response;
        }
        public function test_curl(){
            try {
                $curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => WOOHOLOSERVER_URL.'/api/login',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                ));
                $result = curl_exec($curl);
                if (curl_errno($curl)) {
                    $error_msg = curl_error($curl);
                    $response = new \WP_REST_Response();
                    $response->set_data(array('message'=>'Error! Curl error: '.$error_msg));
                    $response->set_status(200);
                    return $response;
                }
                curl_close($curl);
                $response = new \WP_REST_Response();
                $response->set_data(array('message'=>'Success! Curl this site: ' .$result));
                $response->set_status(200);
                return $response;
            }
            catch (Exception $exception){
                $response = new \WP_REST_Response();
                $response->set_data(array('message'=>'Error: '.$exception));
                $response->set_status(200);
                return $response;
            }
        }

    }
}