<?php
namespace WOOHolo\admin;
use WOOHolo\admin\Menu;
use WOOHolo\admin\Action;
use WOOHolo\Check_Setting;
class GetWay
{
    protected $options=[];
    
    function __construct()
    {
        $this->options= get_option( 'woo_holo' );
    }
    /*
     * check login with holo
     */
    public function login($licence,$status=''){
        $url = $this->get_site_url_ssl();
        if($status=='firstLogin'){
             (new Action())->woo_holo_log('user_name: '.$url.' activeLicense: '.$licence);
        }
        try {
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => WOOHOLOSERVER_URL.'/api/login',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => array('siteUrl' => $url,'activeLicense' => $licence,'status'=>$status),
            ));
            $response = curl_exec($curl);
            if (curl_errno($curl)) {
                $error_msg = curl_error($curl);
                (new Action())->woo_holo_log('Error! Curl error: '.$error_msg);
                 return array('message'=>'Error! Curl error: '.$error_msg);
            }
            curl_close($curl);
            $data =  json_decode($response);
            if(isset($data->responseCode)&&$data->responseCode==200&&isset($data->response->token)){
                (new Menu())->woo_holo_update_option( 'holo_token', false ,false,$data->response->token);
                (new Menu())->woo_holo_update_option( 'holo_token_expires_in', false ,false,time()+$data->response->expires_in/1000);
                (new Action())->woo_holo_log('LOGIN::Get New Token:'.$data->response->token .'Expire In: '.(time()+$data->response->expires_in/1000));
            }
            elseif (isset($data->responseCode)&&$data->responseCode!=200){
                (new Action())->woo_holo_log('Error LOGIN::Get New Token:'.$data->responseCode .': '.$data->message);
            }
            else{
                (new Action())->woo_holo_log('Error LOGIN::Get New Token:'.json_encode($data));
                (new Menu())->woo_holo_update_option( 'holo_token', false ,false,'');
            }
            return $data;
        }
        catch (\Exception $exception){
            return 0;
        }
    }
    /*
    * connect with getWay
    */
    public function connection($endpoint,$data_getway=[],$stop=false){
         $check=(new Check_Setting())->request_available();
        if(isset($check['message'])&&in_array($endpoint,WOOHOLOSERVER_VALIDATE)){
          return $check;
        }
        if( $this->options['holo_token_expires_in']-time()>0){
            $token= $this->options['holo_token'];
            $result= json_encode($data_getway+ $this->options);
            $response = wp_remote_post( WOOHOLOSERVER_URL.'/api/'.$endpoint,
                array(
                    'timeout'     => 36000,
                    'httpversion' => '1.1',
                    'method'      => 'POST',
                    'blocking' => true,
                    'headers'     => array(
                        'Authorization' => 'Bearer ' . $token,
                        'content-type' => 'application/json'
                    ),
                    'body'=>$result
                )
            );
            if (! is_wp_error( $response )) {
                if(is_array( $response )){
                    $data = json_decode(wp_remote_retrieve_body($response));
                    if(isset($data->responseCode)&&$data->responseCode==200){
                        (new Action())->woo_holo_log('Success! '.$endpoint.' root::responseCode: '.$data->responseCode.'::responsMessage: '.$data->message);
                        return $data;
                    }
                    else if(isset($data->responseCode)&&$data->responseCode!=200){
                        (new Action())->woo_holo_log('Error in root: '.$endpoint.' response message: '.$data->message);
                        return array('message'=>__('Error in root: '.$endpoint.' response message: '.$data->message,'wooholo'));
                    }
                    else{
                        (new Action())->woo_holo_log('Error in root: '.$endpoint.' response message: '.$data->message);
                        return array('message'=>__('Error in root: '.$endpoint.' response empty','wooholo'));

                    }
                }
            }
            else {
                (new Action())->woo_holo_log('Error! In root '.$endpoint.' ::ErrorMessage: '.json_encode($response->get_error_message()));
                (new Action())->woo_holo_log('Error! In root '.$endpoint.' ::responseHeader: '.json_encode(wp_remote_retrieve_headers($response)));
                return array('message'=>__('Error Connection to Getway: ','wooholo'));
            }
        }
        else if(!$stop){
            $result_login=$this->login( $this->options['licence_key']);
            if($result_login->responseCode=200&&isset($result_login->response->token)){
                $this->connection($endpoint,$data_getway,true);
            }
        }
    }
    function get_site_url_ssl() {
       $protocols = array( 'http://', 'https://');
       return str_replace( $protocols, 'https://', site_url() );
    }
}