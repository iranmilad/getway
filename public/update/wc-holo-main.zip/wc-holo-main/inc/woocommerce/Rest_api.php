<?php
namespace WOOHolo\woocommerce;

class Rest_api
{
    function __construct(){
        add_filter( "woocommerce_rest_product_object_query", array($this,'woo_holo_filter_woocommerce_rest'), 10, 2 );
    }
    function woo_holo_filter_woocommerce_rest( $args, $request ) {
        $params = $request->get_query_params();
        if(isset($params['meta'])){
            $args['meta_query'] = array(
                array(
                    'key'     => $params['meta'],
                    'value'   => $params['value'],
                    'compare' => 'IN',
                ),
            );
        }
        return $args;
    }
}