<?php
namespace WOOHolo\Admin;
use WOOHolo\admin\Action;
use mysql_xdevapi\Exception;
use WOOHolo\admin\GetWay;
if(!class_exists('Licence')){
    class Licence
    {
        public function __construct()
        {

        }
        public function check_licence_key($licence)
        {
            try {
                $response=(new GetWay)->login($licence,$status='firstLogin');
                if ($response) {
                    (new Action())->woo_holo_log('login successful to holo server and get token');
                    return $response;
                }
            }
            catch (Exception $exception) {
                (new Action())->woo_holo_log('can\'t login to holo server "There is no connection from your host!"');
                return __('There is no connection from your host!','wooholo');
            }
        }
    }
}