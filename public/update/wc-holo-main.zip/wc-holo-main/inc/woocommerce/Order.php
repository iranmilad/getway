<?php
namespace WOOHolo\woocommerce;
use WOOHolo\Admin\Action;
use WOOHolo\admin\GetWay;

class Order
{
    function __construct()
    {
        /**
         *    Add  Column to Orders Table ( Status Holo ) - WooCommerce
         */
        add_filter( 'manage_edit-shop_order_columns', array($this,'woo_holo_add_new_order_admin_list_column'),10,1 );

        add_action( 'manage_shop_order_posts_custom_column',array($this, 'woo_holo_add_new_order_admin_list_column_content'),10,1 );

        /**
         *    sending order data to holo after create new order - WooCommerce
         */
        add_action('woocommerce_new_order',array($this,'woo_holo_woocommerce_new_order'),10,1);

        /**
         *    sending order data to holo after payment order - WooCommerce
         */
        add_action('woocommerce_thankyou',array($this,'woo_holo_woocommerce_tankyou_page_order'),10,1);
        add_action( 'woocommerce_order_status_completed',array($this, 'woo_holo_update_after_wc_order_completed') );
        
        /**
         *    add holo sku product in order item - WooCommerce
         */
        
        add_action( 'woocommerce_checkout_create_order_line_item', array($this,'woo_holo_add_holo_sku_checkout_create_order_line_item'), 20, 4 );
    }

    function woo_holo_add_new_order_admin_list_column( $columns ) {
        $columns['holo_status'] = __('holo status','wooholo');
        return $columns;
    }

    function woo_holo_add_new_order_admin_list_column_content( $column ) {
        global $post;
        if ( 'holo_status' === $column ) {
            echo $holo_status = get_post_meta($post->ID,'holo_status',true);
        }
    }

    function woo_holo_woocommerce_new_order($order_id){
        $order = wc_get_order( $order_id );
        $order_data = $order->get_data(); // The Order data
        $response=(new GetWay)->connection('wcInvoiceRegistration',$order_data);
        if(isset($response->responseCode)&&$response->responseCode==200){
            update_post_meta($order_id,'holo_status',$response->message);
            $order->add_order_note(__('Successful sending of this order to holo','wooholo'));
            (new Action())->woo_holo_log("Successful sending of order($order_id) to holo");
        }
        else{
            $order->add_order_note(__('error in sending of this order to holo','wooholo'));
            (new Action())->woo_holo_log("error in sending of order($order_id) to holo::responseCode: $response->responseCode ::responsMessage: $response->message");

        }
    }

    function woo_holo_woocommerce_tankyou_page_order($order_id){
        $order = wc_get_order( $order_id );
        $order_data = $order->get_data(); // The Order data
        $response=(new GetWay)->connection('wcInvoicePayed',$order_data);
        if(isset($response->responseCode)&&$response->responseCode==200){
            update_post_meta($order_id,'holo_status',$response->message);
            $order->add_order_note(__('Successful sending of this order to holo after payment','wooholo'));
            (new Action())->woo_holo_log("Successful sending of order($order_id) to holo after payment::responseCode: $response->responseCode ::responsMessage: $response->message");
        }
        else{
            $order->add_order_note(__('error in sending of this order to holo after payment','wooholo'));
            (new Action())->woo_holo_log("error in sending of order($order_id) to holo after payment::responseCode: $response->responseCode ::responsMessage: $response->message");
        }
    }
    function woo_holo_update_after_wc_order_completed( $order_id ) {
        $order = wc_get_order( $order_id );
        $order_data = $order->get_data(); // The Order data
        $response=(new GetWay)->connection('wcInvoicePayed',$order_data);
        if(isset($response->responseCode)&&$response->responseCode==200){
            update_post_meta($order_id,'holo_status',$response->message);
            $order->add_order_note(__('Successful sending of this order to holo after payment','wooholo'));
            (new Action())->woo_holo_log("Successful sending of order($order_id) to holo after payment::responseCode: $response->responseCode ::responsMessage: $response->message");
        }
        else{
            $order->add_order_note(__('error in sending of this order to holo after payment','wooholo'));
            (new Action())->woo_holo_log("error in sending of order($order_id) to holo after payment::responseCode: $response->responseCode ::responsMessage: $response->message");
        }
    }

    function woo_holo_add_holo_sku_checkout_create_order_line_item( $item, $cart_item_key, $values, $order )
    {
        $holo_sku=get_post_meta($item->get_product_id(),'_holo_sku',true);
        $item->update_meta_data( '_holo_sku',$holo_sku );
    }
}