<?php
namespace WOOHolo\admin;

if(!class_exists('Action')){
class Action
{
    public function __construct()
    {
        /*
         * remove file log every 10 days
        */
        add_action('woo_holo_remove_file_log',array($this,'remove_file_log'));

    }
    function woo_holo_log( $entry, $mode = 'a', $file = 'plugin' ) {
        // Get WordPress uploads directory.
        $upload_dir = WOOHOLO_PATH;

        // If the entry is array, json_encode.
        if ( is_array( $entry ) ) {
            $entry = json_encode( $entry );
        }

        // Write the log file.
        $file  = $upload_dir . '/' . $file . '.log';
        $file  = fopen( $file, $mode );
        $bytes = fwrite( $file, current_time( 'mysql' ) . "::" . $entry . "\n" );
        fclose( $file );
    }
    function remove_file_log(){
        wp_delete_file(WOOHOLO_PATH.'/plugin.log');
    }
}
}