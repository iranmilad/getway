<?php
namespace WOOHolo\woocommerce;
use WOOHolo\Admin\Action;
use WOOHolo\admin\GetWay;

class Order
{
    function __construct()
    {
        /**
         *    Add  Column to Orders Table ( Status Holo ) - WooCommerce
         */
        add_filter( 'manage_edit-shop_order_columns', array($this,'woo_holo_add_new_order_admin_list_column'),10,1 );

        add_action( 'manage_shop_order_posts_custom_column',array($this, 'woo_holo_add_new_order_admin_list_column_content'),10,1 );

        /**
         *    sending order data to holo after create new order - WooCommerce
         */
        add_action('woocommerce_new_order',array($this,'woo_holo_woocommerce_new_order'),10,1);

        /**
         *    sending order data to holo after payment order - WooCommerce
         */
        add_action('woocommerce_thankyou',array($this,'woo_holo_woocommerce_tankyou_page_order'),10,1);

        add_action( 'woocommerce_order_status_completed',array($this, 'woo_holo_update_after_wc_order_completed') );

        add_action( 'resend_wc_order_to_holo',array($this, 'woo_holo_update_after_wc_order_completed') );

        /**
         *    add holo sku product in order item - WooCommerce
         */
        add_action( 'woocommerce_checkout_create_order_line_item', array($this,'woo_holo_add_holo_sku_checkout_create_order_line_item'), 20, 4 );

        // Adding holo status container admin shop_order pages
        add_action( 'add_meta_boxes', array($this,'woo_holo_add_meta_boxes') );

        // Adding holo status in the meta container admin shop_order pages
        add_action( 'save_post', array($this,'woo_holo_save_wc_order_holo_status_response'), 10, 1 );

    }

    function woo_holo_add_new_order_admin_list_column( $columns ) {
        $columns['holo_status'] = __('holo status','wooholo');
        return $columns;
    }

    function woo_holo_add_new_order_admin_list_column_content( $column ) {
        global $post;
        if ( 'holo_status' === $column ) {
            echo $holo_status = get_post_meta($post->ID,'holo_status',true);
        }
    }

    function woo_holo_woocommerce_new_order($order_id){
        $order = wc_get_order( $order_id );
        $order_data = $order->get_data(); // The Order data
        $response=(new GetWay)->connection('wcInvoiceRegistration',$order_data);
        if(isset($response->responseCode)&&$response->responseCode==200){
            update_post_meta($order_id,'holo_status',$response->message);
            $order->add_order_note(__('Successful sending of this order to holo','wooholo'));
            (new Action())->woo_holo_log("Successful sending of order($order_id) to holo");
        }
        elseif (isset($response->responseCode)&&$response->responseCode!=200){
            $order->add_order_note(__('error '.$response->responseCode.' in sending of this order to holo','wooholo'));
            (new Action())->woo_holo_log("error in sending of order($order_id) to holo::responseCode: $response->responseCode ::responsMessage: $response->message");
        }
        else{
            $order->add_order_note(__('error in sending of this order to holo','wooholo'));
            (new Action())->woo_holo_log("error in sending of order($order_id) to holo::responseCode: ".json_encode($response));
        }
    }

    function woo_holo_woocommerce_tankyou_page_order($order_id){
        $order = wc_get_order( $order_id );
        $order_data = $order->get_data(); // The Order data
        $response=(new GetWay)->connection('wcInvoicePayed',$order_data);
        if(isset($response->responseCode)&&$response->responseCode==200){
            update_post_meta($order_id,'holo_status',$response->message);
            update_post_meta($order_id,'holo_responseCode',$response->responseCode);
            $order->add_order_note(__('Successful sending of this order to holo after payment','wooholo'));
            (new Action())->woo_holo_log("Successful sending of order($order_id) to holo after payment::responseCode: $response->responseCode ::responsMessage: $response->message");
        }
        elseif (isset($response->responseCode)&&$response->responseCode!=200){
            update_post_meta($order_id,'holo_status',$response->message);
            update_post_meta($order_id,'holo_responseCode',$response->responseCode);
            $order->add_order_note(__('error '.$response->responseCode.' in sending of this order to holo after payment','wooholo'));
            (new Action())->woo_holo_log("error in sending of order($order_id) to holo after payment::responseCode: $response->responseCode ::responsMessage: $response->message");
        }
        else{
            update_post_meta($order_id,'holo_responseCode','');
            $order->add_order_note(__('error not response in sending of this order to holo after payment','wooholo'));
            (new Action())->woo_holo_log("error in sending of order($order_id) to holo after payment::responseCode: ".json_encode($response));
        }
    }
    function woo_holo_update_after_wc_order_completed( $order_id ) {
        if(get_post_meta($order_id,'holo_responseCode',true)==200){
            return;
        }
        $order = wc_get_order( $order_id );
        $order_data = $order->get_data(); // The Order data
        $response=(new GetWay)->connection('wcInvoicePayed',$order_data);
        if(isset($response->responseCode)&&$response->responseCode==200){
            update_post_meta($order_id,'holo_status',$response->message);
            update_post_meta($order_id,'holo_responseCode',$response->responseCode);
            $order->add_order_note(__('Successful sending of this order to holo after payment','wooholo'));
            (new Action())->woo_holo_log("Successful sending of order($order_id) to holo after payment::responseCode: $response->responseCode ::responsMessage: $response->message");
        }
        else if(isset($response->responseCode)&&$response->responseCode!=200){
            update_post_meta($order_id,'holo_responseCode',$response->responseCode);
            update_post_meta($order_id,'holo_status',$response->message);
            $order->add_order_note(__('Error '.$response->responseCode.' sending of this order to holo after payment','wooholo'));
            (new Action())->woo_holo_log("Successful sending of order($order_id) to holo after payment::responseCode: $response->responseCode ::responsMessage: $response->message");
        }
        else{
            update_post_meta($order_id,'holo_responseCode','');
            $order->add_order_note(__('error in sending of this order to holo after payment','wooholo'));
            (new Action())->woo_holo_log("error in sending of order($order_id) to holo after payment::responseCode: ".json_encode($response));
        }
    }

    function woo_holo_add_holo_sku_checkout_create_order_line_item( $item, $cart_item_key, $values, $order )
    {
        if($item->get_variation_id()){
            $holo_sku=get_post_meta($item->get_variation_id(),'_holo_sku',true);
        }
        else{
            $holo_sku=get_post_meta($item->get_product_id(),'_holo_sku',true);
        }
        $item->update_meta_data( '_holo_sku',$holo_sku );
    }

    function woo_holo_add_meta_boxes()
    {
        add_meta_box( 'holo_status_b', __('holo status','wooholo'), array($this,'add_holo_status_order'), 'shop_order', 'side', 'core' );
    }
    function add_holo_status_order()
    {
        global $post;
        $holo_responseCode=get_post_meta( $post->ID,'holo_responseCode',true);
        $holo_status=get_post_meta( $post->ID,'holo_status',true);
        $re_holo_status=get_post_meta( $post->ID,'re_holo_status',true);
        if($holo_responseCode==200){
            echo '<p>'.$holo_status.'</p>';
        }
        else{
            echo '<p>'.$holo_status.'</p>';
            ?>
        <p>
            <label><?php
                _e('Invoice submission for holo is not complete Selected to resend the invoice.','wooholo')?></label>
        </p>
            <input type="checkbox" <?php if($re_holo_status) echo 'checked';?> name="re_holo_status" placeholder="">
            <?php
        }
    }
    function woo_holo_save_wc_order_holo_status_response( $post_id ) {
        if(get_post_type($post_id)!='shop_order'){
            return $post_id;
        }
        $holo_responseCode=get_post_meta( $post_id,'holo_responseCode',true);
        $order = wc_get_order( $post_id );
        if($holo_responseCode==200||(!$order->get_status()=='processing'||!$order->get_status()=='completed')){
            return $post_id;
       }
        // If this is an autosave, our form has not been submitted, so we don't want to do anything.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }
        // Check the user's permissions.
        if ( 'page' == $_POST[ 'post_type' ] ) {
            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return $post_id;
            }
        } else {
            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return $post_id;
            }
        }
        if(isset($_POST[ 're_holo_status' ])&&$_POST[ 're_holo_status' ]=='on'){
            do_action('resend_wc_order_to_holo',$post_id);
            update_post_meta( $post_id, 're_holo_status', $_POST[ 're_holo_status' ] );
        }
    }
}