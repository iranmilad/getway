<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
?>
<form method="post">
    <table class="form-table">
        <tbody>
        <tr>
            <th scope="row"><?php _e('Licence Key','wooholo');?></th>
            <td>
                <label for="licence_key">
                    <input name="licence_key" type="text" value="<?php if(isset($_POST['licence_key'])) echo $_POST['licence_key']; elseif(isset($options['licence_key'])) echo $options['licence_key'];?>"/>
                </label>
                <div class="loginstatus">
                    <div class="loader">
                        <div class="sk-circle ">
                            <div class="sk-circle1 sk-child"></div>
                            <div class="sk-circle2 sk-child"></div>
                            <div class="sk-circle3 sk-child"></div>
                            <div class="sk-circle4 sk-child"></div>
                            <div class="sk-circle5 sk-child"></div>
                            <div class="sk-circle6 sk-child"></div>
                            <div class="sk-circle7 sk-child"></div>
                            <div class="sk-circle8 sk-child"></div>
                            <div class="sk-circle9 sk-child"></div>
                            <div class="sk-circle10 sk-child"></div>
                            <div class="sk-circle11 sk-child"></div>
                            <div class="sk-circle12 sk-child"></div>
                        </div>
                    </div>

                </div>
                <p class="description">
                    <small>
                        <?php
                        $link = sprintf( wp_kses( __( 'Check this link <a href="%s">website</a> for get licence key.', 'wooholo' ), array(  'a' => array( 'href' => array() ) ) ), esc_url( WOOHOLOSERVER_GETKEY ) );
                        echo $link;
                        ?>
                    </small>
                </p>
            </td>
        </tr>
        </tbody>
    </table>
    <?php
    wp_nonce_field( 'woo_holo_save_licence_nonce', 'woo_holo_licence_nonce' );

    submit_button( __('Save Change','wooholo'), 'primary', 'woo_holo_save_licence', true );
    ?>
</form>
