<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
do_action('before_holo_banner');?>
<div class="holo-banner">
    <a href="https://www.laravel.clawar-services.org/holoplugin">
        <img style="width: 100%;" alt="holo banner" src="https://www.laravel.clawar-services.org/image/holoplugin.png"/>
    </a>
</div>
<?php do_action('after_holo_banner');?>
