<?php
namespace WOOHolo\admin;
use WOOHolo\admin\GetWay;
use WOOHolo\admin\Action;
use WOOHolo\woocommerce\Product;
class Ajax
{
    function __construct()
    {

        if(is_admin()) {
            /*
             * create new ajax for holo with action woo_holo
             */
            add_action('wp_ajax_woo_holo', array($this,'holo_ajax_request'));
            add_action('wp_ajax_nopriv_woo_holo',  array($this,'holo_ajax_request'));
        }
    }
    function holo_ajax_request() {
        $nonce = $_POST['nonce'];
        $endpoint=$_POST['endpoint'];
        $type=$_POST['type'];
        if ( ! wp_verify_nonce( $nonce, 'ajax-nonce' ) ) {
            die( 'Nonce value cannot be verified.' );
        }
        if($endpoint){
            if($endpoint=='login'){
                $response=(new GetWay())->login( get_option( 'woo_holo' )['licence_key']);
                echo json_encode($response);
            }
            else{
                $response=(new GetWay())->connection($endpoint,$_POST);
                if($endpoint=='getProductCategory'){
                    $holo_categories=[];
                    if(isset($response->responseCode)&&$response->responseCode==200){
                        $holo_categories=$response->response->result;
                        (new Action())->woo_holo_log('Updated Successful get holo categories option');
                        (new Menu())->woo_holo_update_option('holo_categories',false,false,$holo_categories);
                    }
                }
                echo json_encode($response);
            }
        }
        else{
            if($type=='holoCodeUpdate'){
                (new Product())->update_holo_code($_POST['product_id'],$_POST['holoo_id']);
                echo __('Updated Successful','wooholo');
            }
            else if($type=='reset'){
                (new Menu())->set_default_options();
                wp_delete_file(WOOHOLO_PATH.'/plugin.log');
                echo __('Reset plugin data successful.','wooholo');
            }
            
        }
        // Always die in functions echoing ajax content
        die();
    }
}