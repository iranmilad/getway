<?php
namespace WOOHolo\admin;
use WOOHolo\admin\GetWay;
use WOOHolo\admin\Action;
use WOOHolo\woocommerce\Product;
class Ajax
{
    function __construct()
    {
        if(is_admin()) {
            /*
             * create new ajax for holo with action woo_holo
             */
            add_action('wp_ajax_woo_holo', array($this,'holo_ajax_request'));
            add_action('wp_ajax_nopriv_woo_holo',  array($this,'holo_ajax_request'));
        }
    }
    function holo_ajax_request() {
        $nonce = $_POST['nonce'];
        $endpoint=$_POST['endpoint'];
        if ( ! wp_verify_nonce( $nonce, 'ajax-nonce' ) ) {
            die( 'Nonce value cannot be verified.' );
        }
        if($endpoint){
            $response=(new GetWay())->connection($endpoint,$_POST);
            if($endpoint=='getProductCategory'){
                $holo_categories=[];
                if($response->responseCode==200){
                    $holo_categories=$response->response->result;
                    (new Action())->woo_holo_log('Updated Successful get holo categories option');
                    (new Menu())->woo_holo_update_option('holo_categories',false,false,$holo_categories);}
            }
            echo json_encode($response);
         
        }
        else{
            (new Product())->update_holo_code($_POST['product_id'],$_POST['holoo_id']);
            echo __('Updated Successful','wooholo');
        }
        // Always die in functions echoing ajax content
        die();
    }
}