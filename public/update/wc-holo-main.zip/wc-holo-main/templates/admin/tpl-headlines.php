<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
$gateways = WC()->payment_gateways->payment_gateways();
function woo_holo_all_account($accounts,$options,$gateway_id)
{
    $html='';
    foreach ($accounts as $account) {
        $select='';
        if (isset($_POST['payment'][$gateway_id]['number']) ) {
            if ($_POST['payment'][$gateway_id]['number'] ==  $account->sarfasl_Code){
                $select = "selected";
            }
        }
        else if(isset($options['payment'][$gateway_id]['number']) && $options['payment'][$gateway_id]['number'] == $account->sarfasl_Code){
            $select = "selected";
        }
        $html .='<option value="' . $account->sarfasl_Code . '" ' . $select . '>' .$account->sarfasl_Name . '</option>'; //Parent Category
    }
    return $html;
}
if(!empty( $gateways )) {
?>
<form method="post">
    <table class="form-table">
        <tbody>
        <?php

            foreach( $gateways as $gateway ) {
                if( $gateway->enabled == 'yes' ) {?>
                    <tr>
                        <th scope="row">
                            <label for="payment">
                                <?php echo $gateway->get_title()?>
                            </label>
                        </th>
                        <td>
                            <label for="payment_number"> <?php _e('Heading number','wooholo');?></label>
                            <select name="payment[<?php echo $gateway->id?>][number]">
                                <?php echo woo_holo_all_account($accounts,$options,$gateway->id);?>
                            </select>
                        </td>
                        <td>
                            <label for="payment_fee"> <?php _e('Port Fee','wooholo');?></label>
                            <input name="payment[<?php echo $gateway->id?>][fee]" type="text" value="<?php if(isset($_POST['payment'][$gateway->id]['fee'])) echo $_POST['payment'][$gateway->id]['fee']; elseif(isset($options['payment'][$gateway->id]['fee'])) echo $options['payment'][$gateway->id]['fee'];?>"/>
                        </td>
                        <td>
                            <label for="payment_vat"> <?php _e('VAT','wooholo');?></label>
                            <select name="payment[<?php echo $gateway->id?>][vat]" >
                                <option value="0" <?php if(isset($_POST['payment'][$gateway->id]['vat'])&&$_POST['payment'][$gateway->id]['vat']=='0') echo 'selected'; else if(!isset($_POST['payment'][$gateway->id]['vat'])&&isset($options['payment'][$gateway->id]['vat'])&&$options['payment'][$gateway->id]['vat']=='0') echo 'selected'?>>
                                    <?php _e('OFF','wooholo');?>
                                </option>
                                <option value="1" <?php if(isset($_POST['payment'][$gateway->id]['vat'])&&$_POST['payment'][$gateway->id]['vat']=='1') echo 'selected'; else if(!isset($_POST['payment'][$gateway->id]['vat'])&&isset($options['payment'][$gateway->id]['vat'])&&$options['payment'][$gateway->id]['vat']=='1') echo 'selected'?>>
                                    <?php _e('ON','wooholo');?>
                                </option>
                            </select>
                        </td>
                    </tr>
                    <?php
                }
            }

        ?>

        </tbody>
    </table>
    <?php
    wp_nonce_field( 'woo_holo_save_headlines_nonce', 'woo_holo_headlines_nonce' );

    submit_button( __('Save Change','wooholo'), 'primary', 'woo_holo_save_headlines', true );
    ?>
</form>
<?php
}
?>